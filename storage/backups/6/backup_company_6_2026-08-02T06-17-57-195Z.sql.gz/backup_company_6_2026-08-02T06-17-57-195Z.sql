-- MySQL dump 10.13  Distrib 9.7.1, for macos26.4 (arm64)
--
-- Host: localhost    Database: billora
-- ------------------------------------------------------
-- Server version	9.7.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '3fd18d6c-85d6-11f1-94f2-1bd5ddd17f09:1-1659';

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('03f14e71-8652-410e-8192-1ff8ddccfc5d','c3ec937a3b9461d58308e275acd4e6f236494d584addd77c6a513fe2af3c3ac6','2026-08-01 03:38:03.252','20260801000004_quote_discount_type','',NULL,'2026-08-01 03:38:03.252',0),('0d8a232d-e6f5-41f9-ad93-882715eda093','be87830b1368899388217ff73d6e6c5e2eb38953f30fa04c0e8f100efd3c6c8c','2026-07-29 12:03:26.594','20260729120000_add_multi_company_support',NULL,NULL,'2026-07-29 12:03:26.477',1),('19281576-cb09-4d15-9789-e2a14e38af5f','ea8c6f437533a0f10d3aafd9276586c10bee35e5912fff459c32a05affd746f1','2026-07-31 06:27:54.868','20260731260000_kitchen_order_column_fix','',NULL,'2026-07-31 06:27:54.868',0),('2092d337-404c-4748-b10b-a3cc99fa5fbe','33837aaa071037595833b42cdfe8ddb53604adb0e84925ce31afca02b3838080','2026-07-31 04:04:19.191','20260731180000_hsn_sac_audit','',NULL,'2026-07-31 04:04:19.191',0),('25045e7a-61c3-427e-b796-e44ae026b87e','a9c20e76b164ac5703e14ac3e371a7d395abb08387388bc01d3c035419934b35','2026-07-29 11:31:29.546','20260729113129_add_company_settings',NULL,NULL,'2026-07-29 11:31:29.543',1),('26184bd8-71d7-4e2a-97f9-1748250a1b9b','bccf325e1bef4f850d37ae85fb9f530874c38a9a4caa9318ea0c084b7e1c5a48','2026-07-31 05:16:39.280','20260731230000_advance_order','',NULL,'2026-07-31 05:16:39.280',0),('30e7948b-bf9c-4505-8783-d8123bd1aa7a','7a1af15c952d4c5fa98f80333cbc8d851dbfd5ecc4928adfd33b14d3909b8eb4','2026-07-31 05:27:08.402','20260731240000_product_lock','',NULL,'2026-07-31 05:27:08.402',0),('30f260ce-5b8b-4742-bc15-d16ce09053a9','fe6c94291fc1ddeb82f10b6cfd66bd5ab116ed58507e44e573e186fd724f4f30','2026-08-02 03:37:00.037','20260802000000_company_branding_theme','',NULL,'2026-08-02 03:37:00.037',0),('311065b2-3012-4e0c-a859-2387fef0a311','8d1c6a6a1ddffde882d5db0f8a745bfb6d9e868dc9fb397e3b1abfdd8750ff94','2026-07-29 11:35:18.813','20260729113518_add_customer_master',NULL,NULL,'2026-07-29 11:35:18.810',1),('33cd5468-dfd1-4f42-bce1-7784a63ab335','8f41973b53eb78a3fd138a37ba2657513b11829a36570b099dae17532a16b4ec',NULL,'20260730120000_vendor_purchase_module','A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260730120000_vendor_purchase_module\n\nDatabase error code: 1064\n\nDatabase error:\nYou have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near \'WHERE `gstNumber` IS NOT NULL;\n\n-- 3. Purchase Order\nCREATE TABLE `purchase_orde\' at line 2\n\nPlease check the query number 6 from the migration file.\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name=\"20260730120000_vendor_purchase_module\"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name=\"20260730120000_vendor_purchase_module\"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260','2026-07-30 04:54:29.775','2026-07-30 04:53:59.168',0),('3c0433da-0162-4be6-ac39-cd02fca7e739','88147e25c64c7ae8c3c4fbb7e03755993730ae580bf2edbed9347451c2bd4ade','2026-08-02 05:34:32.227','20260802030000_backup_extend','',NULL,'2026-08-02 05:34:32.227',0),('41109aca-f310-4477-b00d-47ef5d3a2172','6b4b9300c38f6d5e729e7360b1525851c554ccf34979cf1c540c4e298238b28c','2026-08-01 03:10:09.405','20260801000002_accounting_quote','',NULL,'2026-08-01 03:10:09.405',0),('41f54ede-ed9e-444f-aaae-20f67f9389c1','4328bb0d19a0c9fe8d25ecd15f680053f8adf26d5c3442c349f051f43e74d392','2026-07-30 03:51:23.630','20260729140000_add_username_back',NULL,NULL,'2026-07-30 03:51:23.626',1),('4485399d-8908-4e98-a1f1-366d47090553','42a6bba649a20af3f4bfd10f207999c5cd74fb9f472499a37294db3b42327857','2026-07-31 07:32:42.533','20260731300000_wastage','',NULL,'2026-07-31 07:32:42.533',0),('4983b973-1a65-423b-8a94-c10efd7b2597','0618b89abfd50c84274d4005c6d071634de72dba7b10de31b051b620b941a9dc','2026-07-31 07:16:48.531','20260731280000_production_plan','',NULL,'2026-07-31 07:16:48.531',0),('4bb834af-79f2-4b8d-83d9-54f423b95aaa','65cb41b9751d492a3916f8aa9164a7575f93e5a0a90f81b61606392b7e3befb0','2026-07-31 07:27:03.413','20260731295000_production_out','',NULL,'2026-07-31 07:27:03.413',0),('4bf42398-afa0-48fe-bc44-a49d50a74938','9a5f2b1f9f4131ea2069ad0332f1d5f0185e776dc6a350f7949262eb5ae8db16','2026-08-01 02:20:14.162','20260801000000_wa_campaign','',NULL,'2026-08-01 02:20:14.162',0),('55c99981-4156-4c63-bb94-68edfb9d5d01','3489f97edc80b11b6d069f4350c867fdac63809fc1b5e788ba1a46488120c25b','2026-07-30 04:26:27.723','20260730100000_gst_management_module',NULL,NULL,'2026-07-30 04:26:27.469',1),('5d4c320d-f464-48e3-9147-1e949d3180a7','7978de64a33e25413a21d5b5dd9e9759ea65a13c511b857878d34361e584a6f6','2026-07-31 05:50:16.268','20260731250000_payment_settings','',NULL,'2026-07-31 05:50:16.268',0),('69f5a91e-db1b-4dcd-800b-4d1e8b434afe','a84ead355bafbce9b583d4a73d36bda7adc8046b76f57ae3a54fd2b466c3779f','2026-08-02 04:40:14.526','20260802010000_gst_item_wise','',NULL,'2026-08-02 04:40:14.526',0),('6b63e9b3-b0df-4496-ac17-4076f605d606','fa8fca5c48af6f420ac8c318f757b2b49fe877ac32aed71fccd016afc14ab10a','2026-07-31 12:21:14.275','20260731310000_whatsapp_template','',NULL,'2026-07-31 12:21:14.275',0),('6c692513-0297-4669-8e49-622f3a9acac4','38264935698ddb3120a24d70a1da5cc1c387820e54f5064ab5afb203463196c2','2026-07-31 05:03:40.275','20260731220000_day_closing','',NULL,'2026-07-31 05:03:40.275',0),('6f0a8e80-9475-4df2-833d-194c792fec5c','e5f58ca9f24c97b71cc0edd1d6f92ca0fb92c4c037f57676e3334c806a526c29','2026-07-31 03:24:41.829','20260731160000_branch_master_expansion','',NULL,'2026-07-31 03:24:41.829',0),('75c3c931-ea83-42f4-b2f3-754c7d8522e9','0e4c84d31e0747aca7ca33c13c2b77e51943473c7182c5243a540b913b0be9d6','2026-07-31 07:23:22.752','20260731290000_production_in','',NULL,'2026-07-31 07:23:22.752',0),('7ec48af0-99de-4ddd-8455-863012fc43d3','cfa619cbf8faafe02ec8ae7e7cf2c1042b00c5062cdfc0577ebafb9d7a9fa6bd','2026-08-01 03:24:32.321','20260801000003_accounting_invoice','',NULL,'2026-08-01 03:24:32.321',0),('82a981cc-72ca-48fb-8d26-cf5d926d652c','f6e0213956d2c131e009a49cdd73164f6ca1404d5f826cc017c856c0183ac0af','2026-07-30 03:23:07.478','20260729130000_multi_company_saas',NULL,NULL,'2026-07-30 03:23:07.319',1),('83ef6912-a8c0-48a0-a94f-6e82954d66d5','027bebfdb6e713004b844801e51dd017e8a8f81e4b60bc839cbc700a7ad3488c','2026-08-01 02:37:43.894','20260801000001_cash_flow','',NULL,'2026-08-01 02:37:43.894',0),('885b4118-b1cc-4fbd-a32b-182c4df0e65b','6d2b366407b6b6d94b3f1ecc7ea08fc372e4808febdf554828dd181aeb3dd686',NULL,'20260730120000_vendor_purchase_module','A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260730120000_vendor_purchase_module\n\nDatabase error code: 1060\n\nDatabase error:\nDuplicate column name \'currentStock\'\n\nPlease check the query number 1 from the migration file.\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name=\"20260730120000_vendor_purchase_module\"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name=\"20260730120000_vendor_purchase_module\"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260','2026-07-30 04:54:44.332','2026-07-30 04:54:37.053',0),('8a59a645-24f5-44fd-a72b-4d5b807c24cf','7b50b8dc7401a79420deb0a65160fe4c90d12e3196d9d761bd29b9ce0d117679','2026-07-31 04:54:51.376','20260731210000_vendor_payment_transaction','',NULL,'2026-07-31 04:54:51.376',0),('8c2960bc-5617-4a40-901b-e22e30696701','5a41b9baadbec4f1e921f734867f05288b06519f452c8fd093d8672a028ee517','2026-07-29 11:44:27.322','20260729114427_add_product_master',NULL,NULL,'2026-07-29 11:44:27.309',1),('a2b657ba-f6a1-4121-8689-27772063503d','f9c429c8b14b165708ae196ab6a714d5f5786b03fa05cf8aaf5b536759a32721','2026-07-30 04:30:46.440','20260730110000_add_unique_hsn_code','',NULL,'2026-07-30 04:30:46.440',0),('adb7de3f-2efb-41a9-881c-61c6b25503c9','49f88aa0ff561fcd44d0e615e929d0c6c706dd4cd09c8e210816524dc8cac988','2026-07-31 06:53:18.892','20260731270000_login_history','',NULL,'2026-07-31 06:53:18.892',0),('c0b67fed-fd68-4ee5-8acb-43c55ca0ec57','b661740832094695c7a0b947020cad54bac21c209e41b62e5311fce785bebb4b','2026-07-31 04:17:51.962','20260731190000_company_gst_audit','',NULL,'2026-07-31 04:17:51.962',0),('c273f0cd-a1bd-4c13-8010-65fec780cb27','2facb2f0c30b5543048a0bfed07aa5df469d0d3a6d15c1862f739b1c2761ba23','2026-07-29 11:26:56.798','20260729112656_add_gst_master',NULL,NULL,'2026-07-29 11:26:56.747',1),('c3f5a682-8b72-4efc-ad76-be6e91de9c5a','b74f0e34a82b88731e295d1cf1066068ae93b8432b0ef455d6eebf47c222d52b','2026-08-01 04:00:49.571','20260801100000_event','',NULL,'2026-08-01 04:00:49.571',0),('c650c029-3056-48f4-9590-57729e400ad5','c95491d41f399a956d584a3b67e6a5b40d534e1c95c4450a0d08dc930fb0020a','2026-07-31 04:38:29.242','20260731200000_expense','',NULL,'2026-07-31 04:38:29.242',0),('d9238b8c-e8cc-49d1-9726-623516b45f85','a22530256c47b43fa83882f521554a85bd0a65a21f1aaf1bd09ac0f6db3da5c1','2026-07-31 03:01:55.659','20260731140000_add_production_mapping','',NULL,'2026-07-31 03:01:55.659',0),('e39d98bc-20b6-4f10-8a52-c25f764935aa','e5dd7cd52b921222ce247af8269c63fa068a1d5fef0f1164c76d1b4b43a9fd51','2026-07-31 03:10:52.918','20260731150000_production_mapping_v2_and_conversion','',NULL,'2026-07-31 03:10:52.918',0),('e7603ff1-fe63-40b7-96da-f8323f8bab76','f9c429c8b14b165708ae196ab6a714d5f5786b03fa05cf8aaf5b536759a32721',NULL,'20260730110000_add_unique_hsn_code','A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260730110000_add_unique_hsn_code\n\nDatabase error code: 1061\n\nDatabase error:\nDuplicate key name \'HSNSac_code_key\'\n\nPlease check the query number 1 from the migration file.\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name=\"20260730110000_add_unique_hsn_code\"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name=\"20260730110000_add_unique_hsn_code\"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260','2026-07-30 04:30:46.438','2026-07-30 04:30:41.605',0),('e7b64d88-127b-4608-88a6-93578c6339d5','df340c2f7a46062506a7d22b2c7ad83288bedbde51f6e87eefb59075431e6936','2026-07-31 03:43:12.568','20260731170000_wallet_top_up','',NULL,'2026-07-31 03:43:12.568',0),('ebfe79cd-678d-41b7-8a1f-dfc268cf4048','1e51f816319f8f5c9af3f73137f9459d8f5d67fc5a73b280da471bca9ae3debe','2026-08-02 04:56:06.480','20260802020000_backup_restore','',NULL,'2026-08-02 04:56:06.480',0),('ecb24baa-8cb3-4051-ae71-50370ca4cafb','1aad9a8bd2fe88eb8fd1f6e620fb6a5f92c3ef7dc0ffab8cbd7c358c46600c77','2026-07-29 11:48:22.867','20260729114822_add_billing_models',NULL,NULL,'2026-07-29 11:48:22.817',1),('f0f51809-01de-4ca2-b83f-c9d1bd453006','6d2b366407b6b6d94b3f1ecc7ea08fc372e4808febdf554828dd181aeb3dd686','2026-07-30 04:54:44.333','20260730120000_vendor_purchase_module','',NULL,'2026-07-30 04:54:44.333',0);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting_invoice`
--

DROP TABLE IF EXISTS `accounting_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounting_invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `invoiceNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unpaid',
  `invoiceDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `dueDate` datetime(3) DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discountAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discountType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '%',
  `taxRate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `taxAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `paidAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounting_invoice_invoiceNumber_key` (`invoiceNumber`),
  KEY `accounting_invoice_companyId_idx` (`companyId`),
  KEY `accounting_invoice_createdByUserId_fkey` (`createdByUserId`),
  KEY `accounting_invoice_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `accounting_invoice_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `accounting_invoice_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `accounting_invoice_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_invoice`
--

LOCK TABLES `accounting_invoice` WRITE;
/*!40000 ALTER TABLE `accounting_invoice` DISABLE KEYS */;
INSERT INTO `accounting_invoice` VALUES (2,6,'INV-0001','1001-Harikrishnan Arumugam','Partial','2026-08-01 00:00:00.000','2026-09-01 00:00:00.000',28000.00,1400.00,'%',18.00,4788.00,31388.00,0.00,NULL,NULL,23,23,'2026-08-01 03:39:52.964','2026-08-01 03:39:52.964');
/*!40000 ALTER TABLE `accounting_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting_invoice_item`
--

DROP TABLE IF EXISTS `accounting_invoice_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounting_invoice_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accountingInvoiceId` int NOT NULL,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unitPrice` decimal(12,2) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `accounting_invoice_item_accountingInvoiceId_idx` (`accountingInvoiceId`),
  CONSTRAINT `accounting_invoice_item_accountingInvoiceId_fkey` FOREIGN KEY (`accountingInvoiceId`) REFERENCES `accounting_invoice` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting_invoice_item`
--

LOCK TABLES `accounting_invoice_item` WRITE;
/*!40000 ALTER TABLE `accounting_invoice_item` DISABLE KEYS */;
INSERT INTO `accounting_invoice_item` VALUES (3,2,'POS Software License','Annual license',2.00,12000.00,24000.00,'2026-08-01 03:39:52.964','2026-08-01 03:39:52.964'),(4,2,'Annual Maintenance','1 Year',1.00,4000.00,4000.00,'2026-08-01 03:39:52.964','2026-08-01 03:39:52.964');
/*!40000 ALTER TABLE `accounting_invoice_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advance_order`
--

DROP TABLE IF EXISTS `advance_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `advance_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `branchId` int DEFAULT NULL,
  `orderNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `deliveryDate` date NOT NULL,
  `deliveryTime` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoiceDate` date NOT NULL,
  `noOfPax` int DEFAULT NULL,
  `categoryName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serviceName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerMobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `landmark` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additionalMobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerGstNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `companyName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referenceNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discountPercent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `discountAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `taxAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `grandTotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `paidAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `dueAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `paymentMode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CASH',
  `cashAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `cardAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `upiAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `walletAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `orderStatus` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `createdByUserId` int NOT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `AdvanceOrder_companyId_orderNumber_key` (`companyId`,`orderNumber`),
  KEY `AdvanceOrder_branchId_fkey` (`branchId`),
  KEY `AdvanceOrder_createdByUserId_fkey` (`createdByUserId`),
  KEY `AdvanceOrder_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `AdvanceOrder_branchId_fkey` FOREIGN KEY (`branchId`) REFERENCES `branch` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `AdvanceOrder_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `AdvanceOrder_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `AdvanceOrder_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advance_order`
--

LOCK TABLES `advance_order` WRITE;
/*!40000 ALTER TABLE `advance_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `advance_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advance_order_item`
--

DROP TABLE IF EXISTS `advance_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `advance_order_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `advanceOrderId` int NOT NULL,
  `companyId` int NOT NULL,
  `productId` int DEFAULT NULL,
  `productName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(12,2) NOT NULL,
  `unitPrice` decimal(12,2) NOT NULL,
  `discountPercent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `discountAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `taxPercent` decimal(5,2) NOT NULL DEFAULT '0.00',
  `taxAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `totalAmount` decimal(12,2) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `AdvanceOrderItem_advanceOrderId_fkey` (`advanceOrderId`),
  KEY `AdvanceOrderItem_productId_fkey` (`productId`),
  KEY `AdvanceOrderItem_companyId_fkey` (`companyId`),
  CONSTRAINT `AdvanceOrderItem_advanceOrderId_fkey` FOREIGN KEY (`advanceOrderId`) REFERENCES `advance_order` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AdvanceOrderItem_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `AdvanceOrderItem_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advance_order_item`
--

LOCK TABLES `advance_order_item` WRITE;
/*!40000 ALTER TABLE `advance_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `advance_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_history`
--

DROP TABLE IF EXISTS `backup_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `backupName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` int NOT NULL DEFAULT '0',
  `storageType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'local',
  `cloudPath` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `compression` tinyint(1) NOT NULL DEFAULT '1',
  `encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `tableCount` int NOT NULL DEFAULT '0',
  `recordCount` int NOT NULL DEFAULT '0',
  `error` text COLLATE utf8mb4_unicode_ci,
  `createdByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `cloudKey` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploadStatus` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NOT_UPLOADED',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `retryCount` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `backup_history_companyId_idx` (`companyId`),
  KEY `backup_history_createdAt_idx` (`createdAt`),
  KEY `backup_history_createdByUserId_fkey` (`createdByUserId`),
  KEY `backup_history_uploadStatus_idx` (`uploadStatus`),
  CONSTRAINT `backup_history_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `backup_history_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_history`
--

LOCK TABLES `backup_history` WRITE;
/*!40000 ALTER TABLE `backup_history` DISABLE KEYS */;
INSERT INTO `backup_history` VALUES (1,6,'Backup 2/8/2026 11:47:57 am','backup_company_6_2026-08-02T06-17-57-195Z.sql',0,'local',NULL,'RUNNING',1,0,0,0,NULL,23,'2026-08-02 06:17:57.229','2026-08-02 06:17:57.229',NULL,'NOT_UPLOADED','E2E test',0);
/*!40000 ALTER TABLE `backup_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_job`
--

DROP TABLE IF EXISTS `backup_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_job` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `scheduledAt` datetime(3) NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `backupId` int DEFAULT NULL,
  `error` text COLLATE utf8mb4_unicode_ci,
  `attempts` int NOT NULL DEFAULT '0',
  `maxAttempts` int NOT NULL DEFAULT '3',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `backup_job_companyId_idx` (`companyId`),
  KEY `backup_job_status_idx` (`status`),
  KEY `backup_job_scheduledAt_idx` (`scheduledAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_job`
--

LOCK TABLES `backup_job` WRITE;
/*!40000 ALTER TABLE `backup_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_log`
--

DROP TABLE IF EXISTS `backup_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `backupId` int DEFAULT NULL,
  `restoreId` int DEFAULT NULL,
  `companyId` int NOT NULL,
  `step` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INFO',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `backup_log_companyId_idx` (`companyId`),
  KEY `backup_log_backupId_idx` (`backupId`),
  KEY `backup_log_restoreId_idx` (`restoreId`),
  CONSTRAINT `backup_log_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_log`
--

LOCK TABLES `backup_log` WRITE;
/*!40000 ALTER TABLE `backup_log` DISABLE KEYS */;
INSERT INTO `backup_log` VALUES (1,1,NULL,6,'START','Backup started','INFO','2026-08-02 06:17:57.236'),(2,1,NULL,6,'DUMP','Generating MySQL dump','INFO','2026-08-02 06:17:57.239');
/*!40000 ALTER TABLE `backup_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_setting`
--

DROP TABLE IF EXISTS `backup_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_setting` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `autoBackupEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `backupTime` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '02:00',
  `retentionDays` int NOT NULL DEFAULT '30',
  `cloudBackupEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `compression` tinyint(1) NOT NULL DEFAULT '1',
  `encryption` tinyint(1) NOT NULL DEFAULT '0',
  `encryptionKey` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `maxBackupCount` int NOT NULL DEFAULT '50',
  PRIMARY KEY (`id`),
  UNIQUE KEY `backup_setting_companyId_key` (`companyId`),
  CONSTRAINT `backup_setting_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_setting`
--

LOCK TABLES `backup_setting` WRITE;
/*!40000 ALTER TABLE `backup_setting` DISABLE KEYS */;
INSERT INTO `backup_setting` VALUES (1,6,0,'02:00',30,0,1,0,NULL,'2026-08-02 06:17:57.183','2026-08-02 06:17:57.183',50);
/*!40000 ALTER TABLE `backup_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `branchName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isHeadOffice` tinyint(1) NOT NULL DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `branchCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branchType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Branch',
  `contactPerson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternateMobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressLine1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressLine2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'India',
  `pincode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gstin` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pan` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `connectionString` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branchDisplayName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dayEndAutoClosing` tinyint(1) NOT NULL DEFAULT '1',
  `customField1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customField2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rewardPoint` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footerMsg` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billCopy` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `openingTime` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closingTime` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `graceHours` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gstSummary` tinyint(1) NOT NULL DEFAULT '1',
  `isBarCodeBill` tinyint(1) NOT NULL DEFAULT '1',
  `couponPercent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `couponValidity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indentApproval` tinyint(1) NOT NULL DEFAULT '1',
  `isDeptKOT` tinyint(1) NOT NULL DEFAULT '1',
  `unitPriceEdit` tinyint(1) NOT NULL DEFAULT '1',
  `billNoReset` tinyint(1) NOT NULL DEFAULT '1',
  `couponVisible` tinyint(1) NOT NULL DEFAULT '1',
  `orderTypeBill` tinyint(1) NOT NULL DEFAULT '1',
  `isZomato` tinyint(1) NOT NULL DEFAULT '1',
  `isSwiggy` tinyint(1) NOT NULL DEFAULT '1',
  `cloudLogo` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industryID` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `textileGST` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fssai` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addr1` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addr2` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `branch_companyId_branchName_key` (`companyId`,`branchName`),
  UNIQUE KEY `branch_companyId_branchCode_key` (`companyId`,`branchCode`),
  KEY `branch_companyId_idx` (`companyId`),
  KEY `createdByUserId` (`createdByUserId`),
  KEY `updatedByUserId` (`updatedByUserId`),
  CONSTRAINT `branch_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `branch_ibfk_1` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `branch_ibfk_2` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES (7,6,'Head Office','123 Business Street, Chennai, Tamil Nadu 600001','+91 98765 43210','info@billorademo.com',1,1,'2026-07-30 04:12:03.575','2026-07-30 04:12:03.575','BR-0001','Branch',NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,'',NULL,1,NULL,NULL,NULL,'Data Source=SQL5053.site4now.net;Initial Catalog=DB_A61E7E_demobd1;User Id=DB_A61E7E_demobd1_admin;Password=t4bill@123;','Only Coffee Vegetarian Restaurant',1,'Remarks','Attender','1','Powered by www.touch4bill.com','2','1','07:00:00','15:00:00','08:00:00',1,0,'10.00','0.0000',0,1,0,1,0,0,0,0,'branch_2_logo.png',NULL,NULL,NULL,NULL,'S2H Foods And Enterprises Pvt Ltd Mahamaha Kulam, Kumbakonam- 612002 GSTIN: 33ABDCSS478H1Z4',''),(9,7,'Head Office',NULL,'+91 98470 11223','hello@oceanview.in',1,1,'2026-08-02 03:54:27.527','2026-08-02 03:54:27.527',NULL,'Branch',NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,NULL,NULL,1,1,1,1,1,1,1,1,NULL,NULL,NULL,NULL,NULL,'15 Marine Drive, Kochi, Kerala 682001',NULL),(10,8,'Head Office',NULL,'+91 99001 22334','hello@greenleaf.in',1,1,'2026-08-02 03:54:27.588','2026-08-02 03:54:27.588',NULL,'Branch',NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,NULL,NULL,1,1,1,1,1,1,1,1,NULL,NULL,NULL,NULL,NULL,'22 MG Road, Bengaluru, Karnataka 560001',NULL);
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_account`
--

DROP TABLE IF EXISTS `cash_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_account` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `accountId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accountName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accountType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Cash',
  `openingBalance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cash_account_accountId_key` (`accountId`),
  KEY `cash_account_companyId_idx` (`companyId`),
  KEY `cash_account_createdByUserId_fkey` (`createdByUserId`),
  KEY `cash_account_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `cash_account_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `cash_account_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `cash_account_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_account`
--

LOCK TABLES `cash_account` WRITE;
/*!40000 ALTER TABLE `cash_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_category`
--

DROP TABLE IF EXISTS `cash_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `categoryId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoryName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoryType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Cash In',
  `displayOrder` int NOT NULL DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cash_category_categoryId_key` (`categoryId`),
  KEY `cash_category_companyId_idx` (`companyId`),
  KEY `cash_category_createdByUserId_fkey` (`createdByUserId`),
  KEY `cash_category_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `cash_category_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `cash_category_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `cash_category_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_category`
--

LOCK TABLES `cash_category` WRITE;
/*!40000 ALTER TABLE `cash_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_transaction`
--

DROP TABLE IF EXISTS `cash_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cash_transaction` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `transactionId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transactionDate` datetime(3) NOT NULL,
  `transactionType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Cash In',
  `categoryId` int DEFAULT NULL,
  `accountId` int DEFAULT NULL,
  `payMode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Cash',
  `amount` decimal(12,2) NOT NULL,
  `partyName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referenceNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cash_transaction_transactionId_key` (`transactionId`),
  KEY `cash_transaction_companyId_idx` (`companyId`),
  KEY `cash_transaction_transactionDate_idx` (`transactionDate`),
  KEY `cash_transaction_categoryId_fkey` (`categoryId`),
  KEY `cash_transaction_accountId_fkey` (`accountId`),
  KEY `cash_transaction_createdByUserId_fkey` (`createdByUserId`),
  KEY `cash_transaction_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `cash_transaction_accountId_fkey` FOREIGN KEY (`accountId`) REFERENCES `cash_account` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `cash_transaction_categoryId_fkey` FOREIGN KEY (`categoryId`) REFERENCES `cash_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `cash_transaction_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `cash_transaction_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `cash_transaction_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_transaction`
--

LOCK TABLES `cash_transaction` WRITE;
/*!40000 ALTER TABLE `cash_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_backup`
--

DROP TABLE IF EXISTS `cloud_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cloud_backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `backupId` int NOT NULL,
  `cloudKey` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cloudUrl` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileSize` int NOT NULL DEFAULT '0',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `error` text COLLATE utf8mb4_unicode_ci,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `uploadedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cloud_backup_companyId_idx` (`companyId`),
  KEY `cloud_backup_backupId_idx` (`backupId`),
  KEY `cloud_backup_status_idx` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_backup`
--

LOCK TABLES `cloud_backup` WRITE;
/*!40000 ALTER TABLE `cloud_backup` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gstNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gstStateCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stateName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gstEnabled` tinyint(1) NOT NULL DEFAULT '1',
  `gstMode` enum('GST_VISIBLE','GST_INCLUDED_HIDDEN','GST_IGST','NO_GST','GST_ITEM_WISE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'GST_VISIBLE',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `roundOffEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `allowInvoiceGstOverride` tinyint(1) NOT NULL DEFAULT '0',
  `defaultHsnRequired` tinyint(1) NOT NULL DEFAULT '0',
  `allowCustomGstRate` tinyint(1) NOT NULL DEFAULT '0',
  `panNumber` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'India',
  `pincode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `defaultBillingMode` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'WITH_GST',
  `invoicePrefix` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'INV',
  `estimatePrefix` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'EST',
  `creditBillPrefix` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'CR',
  `autoNumberGeneration` tinyint(1) DEFAULT '1',
  `decimalPrecision` int DEFAULT '2',
  `defaultPaymentMode` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'CASH',
  `lowStockAlert` decimal(10,2) DEFAULT NULL,
  `negativeStockAllowed` tinyint(1) DEFAULT '0',
  `defaultWarehouseId` int DEFAULT NULL,
  `barcodeSettings` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `defaultPrintTemplateId` int DEFAULT NULL,
  `paperSize` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'A4',
  `printPreviewEnabled` tinyint(1) DEFAULT '1',
  `defaultGstPercentage` decimal(5,2) DEFAULT NULL,
  `igstEnabled` tinyint(1) DEFAULT '0',
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'INR',
  `currencySymbol` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT '₹',
  `timeZone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Asia/Kolkata',
  `dateFormat` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'DD/MM/YYYY',
  `financialYear` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'en',
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `shortCode` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `themePrimary` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `themePrimaryDark` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `themeAccent` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `themeWarm` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `themeBgDark` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `themeBgDarker` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `themeCardDark` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `themeNavBg` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_company_created_by` (`createdByUserId`),
  KEY `fk_company_updated_by` (`updatedByUserId`),
  CONSTRAINT `fk_company_created_by` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_company_updated_by` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (6,'Billora Demo Company',NULL,'123 Business Street, Chennai, Tamil Nadu 600001','+91 98765 43210','info@billorademo.com','33ABCDE1234F1Z5','33','Tamil Nadu',1,'GST_VISIBLE','2026-07-30 04:12:03.573','2026-08-02 03:45:30.778',1,0,0,0,1,NULL,NULL,'India',NULL,NULL,'WITH_GST','INV','EST','CR',1,2,'CASH',NULL,0,NULL,NULL,NULL,'A4',1,NULL,0,'INR','₹','Asia/Kolkata','DD/MM/YYYY',NULL,'en',NULL,23,'AHS','#e05a3a','#c94025','#f07850','#b83a2a','#2a0e0e','#1a0808','#3d1616','#0f172a'),(7,'Ocean View Restaurant',NULL,'15 Marine Drive, Kochi, Kerala 682001','+91 98470 11223','hello@oceanview.in','32ABCDE1234F1Z5','32','Kerala',1,'GST_VISIBLE','2026-08-02 03:54:27.520','2026-08-02 04:01:52.184',1,0,0,0,0,'ABCDE1234F','Kochi','India','682001','https://www.oceanview.in','WITH_GST','INV','EST','CR',1,2,'CASH',NULL,0,NULL,NULL,NULL,'A4',1,NULL,0,'INR','₹','Asia/Kolkata','DD/MM/YYYY',NULL,'en',23,NULL,'OVR','#1d4ed8','#1e40af','#3b82f6','#1e3a8a','#0a1128','#05081a','#12204a','#0f172a'),(8,'Green Leaf Cafe',NULL,'22 MG Road, Bengaluru, Karnataka 560001','+91 99001 22334','hello@greenleaf.in','29ABCDE5678F1Z5','29','Karnataka',1,'GST_VISIBLE','2026-08-02 03:54:27.585','2026-08-02 04:01:52.274',1,0,0,0,0,'WXYZ1234H','Bengaluru','India','560001','https://www.greenleaf.in','WITH_GST','INV','EST','CR',1,2,'CASH',NULL,0,NULL,NULL,NULL,'A4',1,NULL,0,'INR','₹','Asia/Kolkata','DD/MM/YYYY',NULL,'en',23,NULL,'GLC','#16a34a','#15803d','#22c55e','#14532d','#071c10','#03120a','#0d2b1a','#052e16');
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customerName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alternatePhone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressLine2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stateName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stateCode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'India',
  `pincode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gstNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `panNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customerType` enum('INDIVIDUAL','BUSINESS') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INDIVIDUAL',
  `creditLimit` decimal(12,2) NOT NULL DEFAULT '0.00',
  `creditDays` int NOT NULL DEFAULT '0',
  `priceList` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `companyId` int NOT NULL DEFAULT '1',
  `customerCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wallet` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `customer_companyId_idx` (`companyId`),
  KEY `customer_createdByUserId_idx` (`createdByUserId`),
  KEY `customer_updatedByUserId_idx` (`updatedByUserId`),
  CONSTRAINT `customer_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `customer_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `customer_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (15,'Yuvanth','9677192579',NULL,NULL,'Chennai',NULL,NULL,'Tamil Nadu','33','India',NULL,NULL,NULL,'INDIVIDUAL',0.00,0,NULL,NULL,0,NULL,23,'2026-07-30 10:17:34.560','2026-08-01 14:35:55.614',6,NULL,500.00),(16,'Veluru Yuvanth','09677192579',NULL,NULL,'46,F2,IVY Terrace,Chokkanathar nagar 2nd st,Maduravoyal',NULL,NULL,'Tamil Nadu','33','India',NULL,NULL,NULL,'INDIVIDUAL',0.00,0,NULL,NULL,1,NULL,23,'2026-07-30 10:24:39.619','2026-07-31 02:53:24.360',6,NULL,0.00);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `day_closing`
--

DROP TABLE IF EXISTS `day_closing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `day_closing` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `branchId` int NOT NULL,
  `businessDate` date NOT NULL,
  `closedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `closedByUserId` int NOT NULL,
  `createdByUserId` int NOT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DayClosing_companyId_branchId_businessDate_key` (`companyId`,`branchId`,`businessDate`),
  KEY `DayClosing_branchId_fkey` (`branchId`),
  KEY `DayClosing_closedByUserId_fkey` (`closedByUserId`),
  KEY `DayClosing_createdByUserId_fkey` (`createdByUserId`),
  KEY `DayClosing_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `DayClosing_branchId_fkey` FOREIGN KEY (`branchId`) REFERENCES `branch` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `DayClosing_closedByUserId_fkey` FOREIGN KEY (`closedByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `DayClosing_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `DayClosing_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `DayClosing_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `day_closing`
--

LOCK TABLES `day_closing` WRITE;
/*!40000 ALTER TABLE `day_closing` DISABLE KEYS */;
/*!40000 ALTER TABLE `day_closing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimate`
--

DROP TABLE IF EXISTS `estimate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `estimateNumber` varchar(255) NOT NULL,
  `companyId` int NOT NULL,
  `customerId` int DEFAULT NULL,
  `createdByUserId` int NOT NULL,
  `estimateDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expiryDate` datetime DEFAULT NULL,
  `gstMode` enum('GST_VISIBLE','GST_INCLUDED_HIDDEN','GST_IGST','NO_GST','GST_ITEM_WISE') NOT NULL DEFAULT 'GST_VISIBLE',
  `subtotal` decimal(12,2) NOT NULL,
  `discountAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `taxAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `grandTotal` decimal(12,2) NOT NULL,
  `status` enum('PENDING','ACCEPTED','REJECTED','EXPIRED','CONVERTED') NOT NULL DEFAULT 'PENDING',
  `remarks` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_estimate_company_estimateNumber` (`companyId`,`estimateNumber`),
  KEY `fk_estimate_customer` (`customerId`),
  KEY `fk_estimate_createdByUser` (`createdByUserId`),
  CONSTRAINT `fk_estimate_company` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`),
  CONSTRAINT `fk_estimate_createdByUser` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_estimate_customer` FOREIGN KEY (`customerId`) REFERENCES `customer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimate`
--

LOCK TABLES `estimate` WRITE;
/*!40000 ALTER TABLE `estimate` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimate_item`
--

DROP TABLE IF EXISTS `estimate_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimate_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `estimateId` int NOT NULL,
  `productId` int NOT NULL,
  `productNameSnapshot` varchar(255) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unitPrice` decimal(10,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `gstPercentage` decimal(5,2) NOT NULL,
  `cgstPercentage` decimal(5,2) NOT NULL,
  `sgstPercentage` decimal(5,2) NOT NULL,
  `igstPercentage` decimal(5,2) NOT NULL,
  `cgstAmount` decimal(12,2) NOT NULL,
  `sgstAmount` decimal(12,2) NOT NULL,
  `igstAmount` decimal(12,2) NOT NULL,
  `taxAmount` decimal(12,2) NOT NULL,
  `totalAmount` decimal(12,2) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_estimate_item_estimate` (`estimateId`),
  KEY `fk_estimate_item_product` (`productId`),
  CONSTRAINT `fk_estimate_item_estimate` FOREIGN KEY (`estimateId`) REFERENCES `estimate` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_estimate_item_product` FOREIGN KEY (`productId`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimate_item`
--

LOCK TABLES `estimate_item` WRITE;
/*!40000 ALTER TABLE `estimate_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimate_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `eventName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Birthday',
  `startDate` datetime(3) NOT NULL,
  `endDate` datetime(3) NOT NULL,
  `time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `venue` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guests` int NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Scheduled',
  `contact` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `event_companyId_idx` (`companyId`),
  KEY `event_startDate_idx` (`startDate`),
  KEY `event_createdByUserId_fkey` (`createdByUserId`),
  KEY `event_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `event_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `event_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `event_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (2,6,'Customer Appreciation Day','Promotional','2026-08-15 00:00:00.000','2026-08-15 00:00:00.000','10:00 AM','Main Hall',45,'Scheduled','9876543210',NULL,23,23,'2026-08-01 04:15:33.315','2026-08-01 04:15:33.315'),(3,6,'Corporate Annual Meet','Corporate','2026-08-05 00:00:00.000','2026-08-06 00:00:00.000','09:00 AM','Convention Center',200,'Confirmed','9746602303',NULL,23,23,'2026-08-01 04:15:33.377','2026-08-01 04:15:33.377'),(4,6,'Festival Mega Sale','Festival','2026-08-10 00:00:00.000','2026-08-12 00:00:00.000','11:00 AM','City Mall',500,'Pending','9500122580',NULL,23,23,'2026-08-01 04:15:33.420','2026-08-01 04:15:33.420');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense`
--

DROP TABLE IF EXISTS `expense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expense` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `expenseNumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expenseCategoryId` int NOT NULL,
  `expenseDate` datetime NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `vendorId` int DEFAULT NULL,
  `vendorInvoiceNo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comments` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdByUserId` int NOT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `expense_companyId_expenseNumber_key` (`companyId`,`expenseNumber`),
  KEY `expense_expenseCategoryId_fkey` (`expenseCategoryId`),
  KEY `expense_vendorId_fkey` (`vendorId`),
  KEY `expense_createdByUserId_fkey` (`createdByUserId`),
  KEY `expense_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `expense_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `expense_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `expense_expenseCategoryId_fkey` FOREIGN KEY (`expenseCategoryId`) REFERENCES `expense_category` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `expense_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `expense_vendorId_fkey` FOREIGN KEY (`vendorId`) REFERENCES `vendor` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense`
--

LOCK TABLES `expense` WRITE;
/*!40000 ALTER TABLE `expense` DISABLE KEYS */;
/*!40000 ALTER TABLE `expense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense_category`
--

DROP TABLE IF EXISTS `expense_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expense_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `categoryName` varchar(255) NOT NULL,
  `displayOrder` int NOT NULL DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdByUserId` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_expense_category` (`companyId`,`categoryName`),
  KEY `createdByUserId` (`createdByUserId`),
  CONSTRAINT `expense_category_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`),
  CONSTRAINT `expense_category_ibfk_2` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense_category`
--

LOCK TABLES `expense_category` WRITE;
/*!40000 ALTER TABLE `expense_category` DISABLE KEYS */;
INSERT INTO `expense_category` VALUES (1,6,'Salary',1,1,23,'2026-07-31 04:43:17','2026-07-31 04:43:17'),(2,6,'Petrol',2,1,23,'2026-07-31 04:43:17','2026-07-31 04:43:17'),(3,6,'Local Purchase',3,1,23,'2026-07-31 04:43:17','2026-07-31 04:43:17');
/*!40000 ALTER TABLE `expense_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_receipt`
--

DROP TABLE IF EXISTS `goods_receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods_receipt` (
  `id` int NOT NULL AUTO_INCREMENT,
  `grnNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `companyId` int NOT NULL,
  `purchaseOrderId` int NOT NULL,
  `vendorId` int NOT NULL,
  `branchId` int DEFAULT NULL,
  `receiptDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `status` enum('PENDING','PARTIAL','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdByUserId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `GoodsReceipt_companyId_grnNumber_key` (`companyId`,`grnNumber`),
  KEY `GoodsReceipt_companyId_idx` (`companyId`),
  KEY `GoodsReceipt_purchaseOrderId_idx` (`purchaseOrderId`),
  KEY `GoodsReceipt_vendorId_fkey` (`vendorId`),
  KEY `GoodsReceipt_createdByUserId_fkey` (`createdByUserId`),
  CONSTRAINT `GoodsReceipt_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_receipt`
--

LOCK TABLES `goods_receipt` WRITE;
/*!40000 ALTER TABLE `goods_receipt` DISABLE KEYS */;
INSERT INTO `goods_receipt` VALUES (1,'GRN000001',6,3,5,NULL,'2026-07-30 08:59:32.992','PARTIAL',NULL,23,'2026-07-30 08:59:32.992','2026-07-30 08:59:32.992');
/*!40000 ALTER TABLE `goods_receipt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_receipt_item`
--

DROP TABLE IF EXISTS `goods_receipt_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods_receipt_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `goodsReceiptId` int NOT NULL,
  `productId` int NOT NULL,
  `orderedQty` decimal(10,2) NOT NULL,
  `receivedQty` decimal(10,2) NOT NULL,
  `pendingQty` decimal(10,2) NOT NULL,
  `batchNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiryDate` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `GoodsReceiptItem_goodsReceiptId_idx` (`goodsReceiptId`),
  KEY `GoodsReceiptItem_productId_idx` (`productId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_receipt_item`
--

LOCK TABLES `goods_receipt_item` WRITE;
/*!40000 ALTER TABLE `goods_receipt_item` DISABLE KEYS */;
INSERT INTO `goods_receipt_item` VALUES (1,1,17,6.00,6.00,0.00,NULL,NULL,'2026-07-30 08:59:32.994','2026-07-30 08:59:32.994'),(2,1,16,20.00,20.00,0.00,NULL,NULL,'2026-07-30 08:59:32.994','2026-07-30 08:59:32.994');
/*!40000 ALTER TABLE `goods_receipt_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gst_master`
--

DROP TABLE IF EXISTS `gst_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gst_master` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `totalPercentage` decimal(5,2) NOT NULL,
  `cgstPercentage` decimal(5,2) NOT NULL,
  `sgstPercentage` decimal(5,2) NOT NULL,
  `igstPercentage` decimal(5,2) NOT NULL,
  `isCustom` tinyint(1) NOT NULL DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `effectiveFrom` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gst_master`
--

LOCK TABLES `gst_master` WRITE;
/*!40000 ALTER TABLE `gst_master` DISABLE KEYS */;
INSERT INTO `gst_master` VALUES (6,'GST 0%',0.00,0.00,0.00,0.00,0,1,'2026-07-30 03:54:21.652','2026-07-31 03:57:33.058',NULL),(7,'GST 5%',5.00,2.50,2.50,5.00,0,1,'2026-07-30 03:54:21.654','2026-07-30 03:54:21.654',NULL),(8,'GST 12%',12.00,6.00,6.00,12.00,0,1,'2026-07-30 03:54:21.655','2026-07-30 03:54:21.655',NULL),(9,'GST 18%',18.00,9.00,9.00,18.00,0,1,'2026-07-30 03:54:21.656','2026-07-30 03:54:21.656',NULL),(10,'GST 28%',28.00,14.00,14.00,28.00,0,1,'2026-07-30 03:54:21.658','2026-07-30 03:54:21.658',NULL),(12,'GST 30%',30.00,15.00,15.00,30.00,1,1,'2026-08-01 14:42:21.543','2026-08-01 14:42:21.543','2026-08-05 00:00:00.000');
/*!40000 ALTER TABLE `gst_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hsn_sac`
--

DROP TABLE IF EXISTS `hsn_sac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hsn_sac` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HSN',
  `defaultGstRateId` int DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `HSNSac_code_key` (`code`),
  KEY `HSNSac_defaultGstRateId_idx` (`defaultGstRateId`),
  KEY `HSNSac_createdByUserId_fkey` (`createdByUserId`),
  KEY `HSNSac_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `HSNSac_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `HSNSac_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hsn_sac`
--

LOCK TABLES `hsn_sac` WRITE;
/*!40000 ALTER TABLE `hsn_sac` DISABLE KEYS */;
INSERT INTO `hsn_sac` VALUES (1,'0401','Milk and cream','HSN',6,1,'2026-07-30 04:30:52.684','2026-07-31 04:06:42.723',NULL,23),(2,'0713','Dried leguminous vegetables (pulses)','HSN',6,1,'2026-07-30 04:30:52.687','2026-07-30 04:30:52.687',NULL,NULL),(3,'1006','Rice','HSN',7,1,'2026-07-30 04:30:52.689','2026-07-30 04:30:52.689',NULL,NULL),(4,'1901','Food preparations','HSN',9,1,'2026-07-30 04:30:52.691','2026-07-30 04:30:52.691',NULL,NULL),(5,'2106','Food preparations not elsewhere specified','HSN',9,1,'2026-07-30 04:30:52.693','2026-07-30 04:30:52.693',NULL,NULL),(6,'2201','Mineral waters and aerated waters','HSN',9,1,'2026-07-30 04:30:52.696','2026-07-30 04:30:52.696',NULL,NULL),(7,'3004','Medicaments','HSN',8,1,'2026-07-30 04:30:52.698','2026-07-30 04:30:52.698',NULL,NULL),(8,'3304','Beauty or make-up preparations','HSN',10,1,'2026-07-30 04:30:52.701','2026-07-30 04:30:52.701',NULL,NULL),(9,'3401','Soap and washing preparations','HSN',9,1,'2026-07-30 04:30:52.709','2026-07-30 04:30:52.709',NULL,NULL),(10,'3808','Insecticides, herbicides','HSN',9,1,'2026-07-30 04:30:52.716','2026-07-30 04:30:52.716',NULL,NULL),(11,'3923','Plastic articles for packing','HSN',9,1,'2026-07-30 04:30:52.719','2026-07-30 04:30:52.719',NULL,NULL),(12,'4819','Cartons, boxes of paper/paperboard','HSN',9,1,'2026-07-30 04:30:52.721','2026-07-30 04:30:52.721',NULL,NULL),(13,'4901','Printed books, brochures','HSN',6,1,'2026-07-30 04:30:52.724','2026-07-30 04:30:52.724',NULL,NULL),(14,'6109','T-shirts, singlets, tank tops (knitted)','HSN',7,1,'2026-07-30 04:30:52.726','2026-07-30 04:30:52.726',NULL,NULL),(15,'6203','Men\'s suits, jackets, trousers','HSN',8,1,'2026-07-30 04:30:52.729','2026-07-30 04:30:52.729',NULL,NULL),(16,'6204','Women\'s suits, dresses, skirts','HSN',8,1,'2026-07-30 04:30:52.732','2026-07-30 04:30:52.732',NULL,NULL),(17,'6403','Footwear with outer soles of rubber','HSN',9,1,'2026-07-30 04:30:52.733','2026-07-30 04:30:52.733',NULL,NULL),(18,'7113','Articles of jewellery','HSN',NULL,1,'2026-07-30 04:30:52.736','2026-07-30 04:30:52.736',NULL,NULL),(19,'7321','Stoves, ranges, ovens (iron/steel)','HSN',9,1,'2026-07-30 04:30:52.738','2026-07-30 04:30:52.738',NULL,NULL),(20,'8414','Air/vacuum pumps, compressors','HSN',9,1,'2026-07-30 04:30:52.740','2026-07-30 04:30:52.740',NULL,NULL),(21,'8415','Air conditioning machines','HSN',10,1,'2026-07-30 04:30:52.741','2026-07-30 04:30:52.741',NULL,NULL),(22,'8418','Refrigerators, freezers','HSN',9,1,'2026-07-30 04:30:52.743','2026-07-30 04:30:52.743',NULL,NULL),(23,'8422','Dish washing machines, bottling/packing machinery','HSN',9,1,'2026-07-30 04:30:52.745','2026-07-30 04:30:52.745',NULL,NULL),(24,'8443','Printing machinery','HSN',9,1,'2026-07-30 04:30:52.747','2026-07-30 04:30:52.747',NULL,NULL),(25,'8471','Automatic data processing machines (computers)','HSN',9,1,'2026-07-30 04:30:52.750','2026-07-30 04:30:52.750',NULL,NULL),(26,'8504','Electrical transformers, static converters','HSN',9,1,'2026-07-30 04:30:52.752','2026-07-30 04:30:52.752',NULL,NULL),(27,'8507','Electric accumulators (batteries)','HSN',10,1,'2026-07-30 04:30:52.755','2026-07-30 04:30:52.755',NULL,NULL),(28,'8517','Telephones, smartphones, communication apparatus','HSN',9,1,'2026-07-30 04:30:52.757','2026-07-30 04:30:52.757',NULL,NULL),(29,'8528','Monitors, projectors, TVs','HSN',9,1,'2026-07-30 04:30:52.758','2026-07-30 04:30:52.758',NULL,NULL),(30,'8703','Motor cars for transport of persons','HSN',10,1,'2026-07-30 04:30:52.760','2026-07-30 04:30:52.760',NULL,NULL),(31,'8711','Motorcycles (including mopeds)','HSN',10,1,'2026-07-30 04:30:52.761','2026-07-30 04:30:52.761',NULL,NULL),(32,'9401','Seats and chairs','HSN',9,1,'2026-07-30 04:30:52.763','2026-07-30 04:30:52.763',NULL,NULL),(33,'9403','Other furniture and parts','HSN',9,1,'2026-07-30 04:30:52.765','2026-07-30 04:30:52.765',NULL,NULL),(34,'9503','Toys, games, sports requisites','HSN',8,1,'2026-07-30 04:30:52.767','2026-07-30 04:30:52.767',NULL,NULL),(35,'9608','Pens, pencils, crayons, chalk','HSN',9,1,'2026-07-30 04:30:52.768','2026-07-30 04:30:52.768',NULL,NULL),(36,'9954','Construction services','SAC',9,1,'2026-07-30 04:30:52.773','2026-07-30 04:30:52.773',NULL,NULL),(37,'9961','Financial services','SAC',9,1,'2026-07-30 04:30:52.775','2026-07-30 04:30:52.775',NULL,NULL),(38,'9963','Real estate services','SAC',9,1,'2026-07-30 04:30:52.778','2026-07-30 04:30:52.778',NULL,NULL),(39,'9964','Rental services','SAC',9,1,'2026-07-30 04:30:52.779','2026-07-30 04:30:52.779',NULL,NULL),(40,'9965','Transport services','SAC',7,1,'2026-07-30 04:30:52.781','2026-07-30 04:30:52.781',NULL,NULL),(41,'9966','Postal and courier services','SAC',9,1,'2026-07-30 04:30:52.782','2026-07-30 04:30:52.782',NULL,NULL),(42,'9967','Telecom services','SAC',9,1,'2026-07-30 04:30:52.783','2026-07-30 04:30:52.783',NULL,NULL),(43,'9968','IT and BPO services','SAC',9,1,'2026-07-30 04:30:52.785','2026-07-30 04:30:52.785',NULL,NULL),(44,'9971','Business consulting services','SAC',9,1,'2026-07-30 04:30:52.787','2026-07-30 04:30:52.787',NULL,NULL),(45,'9972','Legal and accounting services','SAC',9,1,'2026-07-30 04:30:52.789','2026-07-30 04:30:52.789',NULL,NULL),(46,'9973','Management consulting services','SAC',9,1,'2026-07-30 04:30:52.791','2026-07-30 04:30:52.791',NULL,NULL),(47,'9982','Education services','SAC',9,1,'2026-07-30 04:30:52.793','2026-07-30 04:30:52.793',NULL,NULL),(48,'9985','Support services','SAC',9,1,'2026-07-30 04:30:52.795','2026-07-30 04:30:52.795',NULL,NULL),(49,'9986','Healthcare services','SAC',6,1,'2026-07-30 04:30:52.797','2026-07-30 04:30:52.797',NULL,NULL),(50,'9988','Manufacturing services','SAC',9,1,'2026-07-30 04:30:52.798','2026-07-30 04:30:52.798',NULL,NULL),(51,'9991','Public administration services','SAC',6,1,'2026-07-30 04:30:52.799','2026-07-30 04:30:52.799',NULL,NULL),(52,'9992','Social services','SAC',6,1,'2026-07-30 04:30:52.801','2026-07-30 04:30:52.801',NULL,NULL),(54,'0403','Milk','HSN',10,1,'2026-08-01 14:40:51.660','2026-08-01 14:40:51.660',23,23);
/*!40000 ALTER TABLE `hsn_sac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indent`
--

DROP TABLE IF EXISTS `indent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `indent` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indentNumber` varchar(191) NOT NULL,
  `companyId` int NOT NULL,
  `branchId` int DEFAULT NULL,
  `indentDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `requestedBy` varchar(191) NOT NULL,
  `department` varchar(191) NOT NULL,
  `priority` varchar(191) NOT NULL DEFAULT 'MEDIUM',
  `requiredDate` datetime(3) DEFAULT NULL,
  `remarks` varchar(191) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'PENDING',
  `createdByUserId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `indent_indentNumber_companyId_key` (`indentNumber`,`companyId`),
  KEY `indent_companyId_fkey` (`companyId`),
  KEY `indent_createdByUserId_fkey` (`createdByUserId`),
  CONSTRAINT `indent_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `indent_ibfk_2` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indent`
--

LOCK TABLES `indent` WRITE;
/*!40000 ALTER TABLE `indent` DISABLE KEYS */;
INSERT INTO `indent` VALUES (1,'IND000001',6,NULL,'2026-07-30 09:49:01.785','John','Kitchen','HIGH','2026-08-01 00:00:00.000',NULL,'APPROVED',23,'2026-07-30 09:49:01.785','2026-08-01 14:21:59.350'),(2,'IND000002',6,NULL,'2026-08-01 14:21:36.142','Yuvanth','Store','HIGH',NULL,NULL,'CANCELLED',23,'2026-08-01 14:21:36.142','2026-08-01 14:22:03.835');
/*!40000 ALTER TABLE `indent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `indent_item`
--

DROP TABLE IF EXISTS `indent_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `indent_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indentId` int NOT NULL,
  `productId` int NOT NULL,
  `currentStock` decimal(10,2) NOT NULL,
  `requiredQty` decimal(10,2) NOT NULL,
  `remarks` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `indent_item_indentId_fkey` (`indentId`),
  KEY `indent_item_productId_fkey` (`productId`),
  CONSTRAINT `indent_item_ibfk_1` FOREIGN KEY (`indentId`) REFERENCES `indent` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `indent_item_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `indent_item`
--

LOCK TABLES `indent_item` WRITE;
/*!40000 ALTER TABLE `indent_item` DISABLE KEYS */;
INSERT INTO `indent_item` VALUES (1,1,17,6.00,6.00,NULL,'2026-07-30 09:49:01.801','2026-07-30 09:49:01.801'),(2,1,16,20.00,20.00,NULL,'2026-07-30 09:49:01.805','2026-07-30 09:49:01.805'),(3,2,16,7.00,1.00,NULL,'2026-08-01 14:21:36.145','2026-08-01 14:21:36.145');
/*!40000 ALTER TABLE `indent_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_ledger`
--

DROP TABLE IF EXISTS `inventory_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_ledger` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `productId` int NOT NULL,
  `branchId` int DEFAULT NULL,
  `quantityIn` decimal(10,2) NOT NULL DEFAULT '0.00',
  `quantityOut` decimal(10,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(10,2) NOT NULL,
  `referenceType` enum('OPENING_STOCK','PURCHASE','SALE','SALES_RETURN','PURCHASE_RETURN','DAMAGE','ADJUSTMENT','PRODUCTION_IN','PRODUCTION_OUT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `referenceId` int NOT NULL,
  `referenceNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdByUserId` int NOT NULL,
  `movementDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `InventoryLedger_companyId_idx` (`companyId`),
  KEY `InventoryLedger_productId_idx` (`productId`),
  KEY `InventoryLedger_referenceType_referenceId_idx` (`referenceType`,`referenceId`),
  KEY `InventoryLedger_createdByUserId_fkey` (`createdByUserId`),
  CONSTRAINT `InventoryLedger_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_ledger`
--

LOCK TABLES `inventory_ledger` WRITE;
/*!40000 ALTER TABLE `inventory_ledger` DISABLE KEYS */;
INSERT INTO `inventory_ledger` VALUES (1,6,17,NULL,6.00,0.00,6.00,'PURCHASE',1,'GRN000001',NULL,23,'2026-07-30 08:59:33.003','2026-07-30 08:59:33.003'),(2,6,16,NULL,20.00,0.00,20.00,'PURCHASE',1,'GRN000001',NULL,23,'2026-07-30 08:59:33.007','2026-07-30 08:59:33.007'),(3,6,17,NULL,0.00,6.00,0.00,'SALE',1,'SO000001',NULL,23,'2026-07-30 09:16:08.620','2026-07-30 09:16:08.620'),(4,6,16,NULL,0.00,20.00,0.00,'SALE',1,'SO000001',NULL,23,'2026-07-30 09:16:08.624','2026-07-30 09:16:08.624'),(5,6,17,NULL,6.00,0.00,6.00,'ADJUSTMENT',1,'SA000001','Stock Audit Adjustment - EXCESS: 6',23,'2026-07-30 09:31:26.476','2026-07-30 09:31:26.476'),(6,6,16,NULL,20.00,0.00,20.00,'ADJUSTMENT',1,'SA000001','Stock Audit Adjustment - EXCESS: 20',23,'2026-07-30 09:31:26.480','2026-07-30 09:31:26.480'),(7,6,17,NULL,0.00,1.00,5.00,'SALE',10,'INV6-0001',NULL,23,'2026-07-30 10:18:21.661','2026-07-30 10:18:21.661'),(8,6,16,NULL,0.00,1.00,19.00,'SALE',10,'INV6-0001',NULL,23,'2026-07-30 10:18:21.665','2026-07-30 10:18:21.665'),(9,6,17,NULL,0.00,1.00,4.00,'SALE',11,'INV6-0002',NULL,23,'2026-07-30 11:40:10.497','2026-07-30 11:40:10.497'),(10,6,16,NULL,0.00,1.00,18.00,'SALE',11,'INV6-0002',NULL,23,'2026-07-30 11:40:10.501','2026-07-30 11:40:10.501'),(11,6,17,NULL,0.00,1.00,3.00,'SALE',12,'INV6-0003',NULL,23,'2026-07-30 11:42:21.211','2026-07-30 11:42:21.211'),(12,6,16,NULL,0.00,1.00,17.00,'SALE',12,'INV6-0003',NULL,23,'2026-07-30 11:42:21.214','2026-07-30 11:42:21.214'),(15,6,17,NULL,0.00,2.00,1.00,'SALE',15,'INV6-0004',NULL,23,'2026-07-31 05:57:54.373','2026-07-31 05:57:54.373'),(16,6,16,NULL,0.00,1.00,16.00,'SALE',15,'INV6-0004',NULL,23,'2026-07-31 05:57:54.377','2026-07-31 05:57:54.377'),(17,6,17,NULL,0.00,1.00,0.00,'SALE',16,'INV6-0005',NULL,23,'2026-07-31 06:01:28.814','2026-07-31 06:01:28.814'),(18,6,16,NULL,0.00,2.00,14.00,'SALE',16,'INV6-0005',NULL,23,'2026-07-31 06:01:28.817','2026-07-31 06:01:28.817'),(19,6,16,NULL,0.00,2.00,12.00,'SALE',17,'INV6-0006',NULL,23,'2026-07-31 06:01:45.150','2026-07-31 06:01:45.150'),(20,6,16,NULL,0.00,3.00,9.00,'SALE',18,'INV6-0007',NULL,23,'2026-07-31 06:03:15.298','2026-07-31 06:03:15.298'),(21,6,16,NULL,0.00,2.00,7.00,'SALE',19,'INV6-0008',NULL,23,'2026-08-01 14:17:41.561','2026-08-01 14:17:41.561');
/*!40000 ALTER TABLE `inventory_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `companyId` int NOT NULL,
  `customerId` int DEFAULT NULL,
  `createdByUserId` int NOT NULL,
  `invoiceDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `subtotal` decimal(12,2) NOT NULL,
  `discountAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `taxAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `grandTotal` decimal(12,2) NOT NULL,
  `gstMode` enum('GST_VISIBLE','GST_INCLUDED_HIDDEN','GST_IGST','NO_GST','GST_ITEM_WISE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'GST_VISIBLE',
  `paymentStatus` enum('PAID','PENDING','PARTIAL') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `invoiceStatus` enum('DRAFT','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `branchId` int DEFAULT NULL,
  `salesPerson` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentMode` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cashReceived` decimal(12,2) DEFAULT '0.00',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `deletedAt` datetime(3) DEFAULT NULL,
  `deletedByUserId` int DEFAULT NULL,
  `deleteReason` text COLLATE utf8mb4_unicode_ci,
  `estimateId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_invoiceNumber_key` (`invoiceNumber`),
  KEY `invoice_companyId_fkey` (`companyId`),
  KEY `invoice_customerId_fkey` (`customerId`),
  KEY `invoice_createdByUserId_fkey` (`createdByUserId`),
  KEY `invoice_estimateId_idx` (`estimateId`),
  CONSTRAINT `invoice_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `invoice_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `invoice_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `customer` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `invoice_estimateId_fkey` FOREIGN KEY (`estimateId`) REFERENCES `estimate` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` VALUES (10,'INV6-0001',6,15,23,'2026-07-30 10:18:21.645',234.00,0.00,11.70,245.70,'GST_VISIBLE','PENDING','COMPLETED','2026-07-30 10:18:21.645','2026-07-30 10:18:21.645',NULL,NULL,'CASH',0.00,NULL,NULL,NULL,NULL,NULL),(11,'INV6-0002',6,NULL,23,'2026-07-30 11:40:10.476',234.00,4.68,11.70,241.02,'GST_VISIBLE','PENDING','COMPLETED','2026-07-30 11:40:10.476','2026-07-30 11:40:10.476',NULL,NULL,'CASH',0.00,NULL,NULL,NULL,NULL,NULL),(12,'INV6-0003',6,NULL,23,'2026-07-30 11:42:21.202',234.00,4.68,11.70,241.02,'GST_VISIBLE','PENDING','COMPLETED','2026-07-30 11:42:21.202','2026-07-30 11:42:21.202',NULL,NULL,'CASH',0.00,NULL,NULL,NULL,NULL,NULL),(15,'INV6-0004',6,NULL,23,'2026-07-31 05:57:54.359',268.00,0.00,13.40,281.40,'GST_VISIBLE','PENDING','COMPLETED','2026-07-31 05:57:54.359','2026-07-31 05:57:54.359',NULL,NULL,'CASH',0.00,NULL,NULL,NULL,NULL,NULL),(16,'INV6-0005',6,NULL,23,'2026-07-31 06:01:28.807',434.00,0.00,21.70,455.70,'GST_VISIBLE','PENDING','COMPLETED','2026-07-31 06:01:28.807','2026-07-31 06:01:28.807',NULL,NULL,'CASH',0.00,NULL,NULL,NULL,NULL,NULL),(17,'INV6-0006',6,NULL,23,'2026-07-31 06:01:45.140',400.00,0.00,20.00,420.00,'GST_VISIBLE','PENDING','COMPLETED','2026-07-31 06:01:45.140','2026-07-31 06:01:45.140',NULL,NULL,'CASH',0.00,NULL,NULL,NULL,NULL,NULL),(18,'INV6-0007',6,NULL,23,'2026-07-31 06:03:15.292',600.00,0.00,30.00,630.00,'GST_VISIBLE','PENDING','COMPLETED','2026-07-31 06:03:15.292','2026-07-31 06:03:15.292',NULL,NULL,'CASH',0.00,NULL,NULL,NULL,NULL,NULL),(19,'INV6-0008',6,NULL,23,'2026-08-01 14:17:41.499',400.00,0.00,0.00,400.00,'GST_VISIBLE','PAID','COMPLETED','2026-08-01 14:17:41.499','2026-08-01 14:19:37.839',NULL,NULL,'CASH',400.00,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_item`
--

DROP TABLE IF EXISTS `invoice_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceId` int NOT NULL,
  `productId` int NOT NULL,
  `productNameSnapshot` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unitPrice` decimal(10,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `gstPercentage` decimal(5,2) NOT NULL,
  `cgstPercentage` decimal(5,2) NOT NULL,
  `sgstPercentage` decimal(5,2) NOT NULL,
  `igstPercentage` decimal(5,2) NOT NULL,
  `cgstAmount` decimal(12,2) NOT NULL,
  `sgstAmount` decimal(12,2) NOT NULL,
  `igstAmount` decimal(12,2) NOT NULL,
  `taxAmount` decimal(12,2) NOT NULL,
  `totalAmount` decimal(12,2) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_item_invoiceId_fkey` (`invoiceId`),
  KEY `invoice_item_productId_fkey` (`productId`),
  CONSTRAINT `invoice_item_invoiceId_fkey` FOREIGN KEY (`invoiceId`) REFERENCES `invoice` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `invoice_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_item`
--

LOCK TABLES `invoice_item` WRITE;
/*!40000 ALTER TABLE `invoice_item` DISABLE KEYS */;
INSERT INTO `invoice_item` VALUES (14,10,17,'Milk',1.00,34.00,34.00,5.00,2.50,2.50,5.00,0.85,0.85,0.00,1.70,35.70,'2026-07-30 10:18:21.648','2026-07-30 10:18:21.648'),(15,10,16,'Rice',1.00,200.00,200.00,5.00,2.50,2.50,5.00,5.00,5.00,0.00,10.00,210.00,'2026-07-30 10:18:21.648','2026-07-30 10:18:21.648'),(16,11,17,'Milk',1.00,34.00,34.00,5.00,2.50,2.50,5.00,0.85,0.85,0.00,1.70,35.70,'2026-07-30 11:40:10.481','2026-07-30 11:40:10.481'),(17,11,16,'Rice',1.00,200.00,200.00,5.00,2.50,2.50,5.00,5.00,5.00,0.00,10.00,210.00,'2026-07-30 11:40:10.481','2026-07-30 11:40:10.481'),(18,12,17,'Milk',1.00,34.00,34.00,5.00,2.50,2.50,5.00,0.85,0.85,0.00,1.70,35.70,'2026-07-30 11:42:21.204','2026-07-30 11:42:21.204'),(19,12,16,'Rice',1.00,200.00,200.00,5.00,2.50,2.50,5.00,5.00,5.00,0.00,10.00,210.00,'2026-07-30 11:42:21.204','2026-07-30 11:42:21.204'),(22,15,17,'Milk',2.00,34.00,68.00,5.00,2.50,2.50,5.00,1.70,1.70,0.00,3.40,71.40,'2026-07-31 05:57:54.363','2026-07-31 05:57:54.363'),(23,15,16,'Rice',1.00,200.00,200.00,5.00,2.50,2.50,5.00,5.00,5.00,0.00,10.00,210.00,'2026-07-31 05:57:54.363','2026-07-31 05:57:54.363'),(24,16,17,'Milk',1.00,34.00,34.00,5.00,2.50,2.50,5.00,0.85,0.85,0.00,1.70,35.70,'2026-07-31 06:01:28.810','2026-07-31 06:01:28.810'),(25,16,16,'Rice',2.00,200.00,400.00,5.00,2.50,2.50,5.00,10.00,10.00,0.00,20.00,420.00,'2026-07-31 06:01:28.810','2026-07-31 06:01:28.810'),(26,17,16,'Rice',2.00,200.00,400.00,5.00,2.50,2.50,5.00,10.00,10.00,0.00,20.00,420.00,'2026-07-31 06:01:45.143','2026-07-31 06:01:45.143'),(27,18,16,'Rice',3.00,200.00,600.00,5.00,2.50,2.50,5.00,15.00,15.00,0.00,30.00,630.00,'2026-07-31 06:03:15.294','2026-07-31 06:03:15.294'),(28,19,16,'Rice',2.00,200.00,400.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,400.00,'2026-08-01 14:17:41.515','2026-08-01 14:17:41.515');
/*!40000 ALTER TABLE `invoice_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_payment`
--

DROP TABLE IF EXISTS `invoice_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_payment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `paymentNumber` varchar(255) NOT NULL,
  `companyId` int NOT NULL,
  `invoiceId` int NOT NULL,
  `customerId` int DEFAULT NULL,
  `paymentDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `amount` decimal(12,2) NOT NULL,
  `paymentMethod` enum('CASH','BANK','UPI','CARD','CHEQUE','WALLET') NOT NULL,
  `referenceNumber` varchar(255) DEFAULT NULL,
  `notes` text,
  `createdByUserId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_payment_company_id_payment_number_key` (`companyId`,`paymentNumber`),
  KEY `invoice_payment_invoice_id_idx` (`invoiceId`),
  KEY `invoice_payment_customer_id_idx` (`customerId`),
  KEY `invoice_payment_company_id_idx` (`companyId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_payment`
--

LOCK TABLES `invoice_payment` WRITE;
/*!40000 ALTER TABLE `invoice_payment` DISABLE KEYS */;
INSERT INTO `invoice_payment` VALUES (1,'CPAY000001',6,19,NULL,'2026-08-01 14:19:21.955',200.00,'CASH',NULL,NULL,23,'2026-08-01 14:19:21.955','2026-08-01 14:19:21.955'),(2,'CPAY000002',6,19,NULL,'2026-08-01 14:19:37.838',200.00,'CASH',NULL,NULL,23,'2026-08-01 14:19:37.838','2026-08-01 14:19:37.838');
/*!40000 ALTER TABLE `invoice_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kitchen_order`
--

DROP TABLE IF EXISTS `kitchen_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kitchen_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kotNumber` varchar(255) NOT NULL,
  `companyId` int NOT NULL,
  `invoiceId` int NOT NULL,
  `invoiceNumber` varchar(255) NOT NULL,
  `customerId` int DEFAULT NULL,
  `customerName` varchar(255) DEFAULT NULL,
  `orderType` enum('DINE_IN','TAKE_AWAY','DELIVERY') NOT NULL DEFAULT 'DINE_IN',
  `orderStatus` enum('NEW','ACCEPTED','PREPARING','READY','SERVED') NOT NULL DEFAULT 'NEW',
  `priority` enum('LOW','NORMAL','HIGH','URGENT') NOT NULL DEFAULT 'NORMAL',
  `tableNumber` varchar(255) DEFAULT NULL,
  `tokenNumber` varchar(255) DEFAULT NULL,
  `orderTime` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `acceptedTime` datetime(3) DEFAULT NULL,
  `preparingTime` datetime(3) DEFAULT NULL,
  `readyTime` datetime(3) DEFAULT NULL,
  `servedTime` datetime(3) DEFAULT NULL,
  `notes` text,
  `createdByUserId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `kitchen_order_company_id_kot_number_key` (`companyId`,`kotNumber`),
  KEY `kitchen_order_invoice_id_idx` (`invoiceId`),
  KEY `kitchen_order_company_id_idx` (`companyId`),
  KEY `kitchen_order_order_status_idx` (`orderStatus`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kitchen_order`
--

LOCK TABLES `kitchen_order` WRITE;
/*!40000 ALTER TABLE `kitchen_order` DISABLE KEYS */;
INSERT INTO `kitchen_order` VALUES (1,'KOT000001',6,19,'INV6-0008',NULL,NULL,'DINE_IN','SERVED','NORMAL',NULL,NULL,'2026-08-01 14:17:41.585','2026-08-01 14:20:08.202','2026-08-01 14:20:11.359','2026-08-01 14:20:13.552','2026-08-01 14:20:15.610',NULL,23,'2026-08-01 14:17:41.585','2026-08-01 14:20:15.613');
/*!40000 ALTER TABLE `kitchen_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kitchen_order_item`
--

DROP TABLE IF EXISTS `kitchen_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kitchen_order_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kitchenOrderId` int NOT NULL,
  `productId` int NOT NULL,
  `productNameSnapshot` varchar(255) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `specialInstructions` text,
  `itemStatus` enum('NEW','ACCEPTED','PREPARING','READY','SERVED') NOT NULL DEFAULT 'NEW',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `kitchen_order_item_kitchen_order_id_idx` (`kitchenOrderId`),
  KEY `kitchen_order_item_product_id_idx` (`productId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kitchen_order_item`
--

LOCK TABLES `kitchen_order_item` WRITE;
/*!40000 ALTER TABLE `kitchen_order_item` DISABLE KEYS */;
INSERT INTO `kitchen_order_item` VALUES (1,1,16,'Rice',2.00,'KG',NULL,'SERVED','2026-08-01 14:17:41.585','2026-08-01 14:20:15.611');
/*!40000 ALTER TABLE `kitchen_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LoginHistory`
--

DROP TABLE IF EXISTS `LoginHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LoginHistory` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `loginAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `ipAddress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userAgent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `LoginHistory_userId_fkey` (`userId`),
  CONSTRAINT `LoginHistory_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LoginHistory`
--

LOCK TABLES `LoginHistory` WRITE;
/*!40000 ALTER TABLE `LoginHistory` DISABLE KEYS */;
INSERT INTO `LoginHistory` VALUES (10,23,'2026-07-30 04:15:24.549','::1','curl/8.7.1',1),(11,23,'2026-07-30 04:16:32.163','::1','curl/8.7.1',1),(13,23,'2026-07-30 04:34:19.971','::1','curl/8.7.1',1),(14,23,'2026-07-30 04:40:16.818','::1','curl/8.7.1',1),(15,23,'2026-07-30 04:41:30.893','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(16,30,'2026-07-30 04:42:41.592','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(17,23,'2026-07-30 04:46:29.333','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(18,23,'2026-07-30 04:51:16.179','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(19,30,'2026-07-30 04:53:34.653','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(20,23,'2026-07-30 05:51:34.998','::1','curl/8.7.1',1),(21,23,'2026-07-30 05:51:40.449','::1','curl/8.7.1',1),(22,23,'2026-07-30 05:51:53.897','::1','curl/8.7.1',1),(23,23,'2026-07-30 05:55:27.099','::1','curl/8.7.1',1),(24,23,'2026-07-30 05:55:39.423','::1','curl/8.7.1',1),(25,23,'2026-07-30 05:55:40.600','::1','curl/8.7.1',1),(26,23,'2026-07-30 05:56:54.505','::1','curl/8.7.1',1),(27,23,'2026-07-30 06:04:39.366','::1','curl/8.7.1',1),(28,23,'2026-07-30 06:05:35.094','::1','curl/8.7.1',1),(29,23,'2026-07-30 06:05:43.430','::1','curl/8.7.1',1),(30,23,'2026-07-30 06:07:27.785','::1','curl/8.7.1',1),(31,23,'2026-07-30 06:08:33.101','::1','curl/8.7.1',1),(32,23,'2026-07-30 06:13:20.486','::1','curl/8.7.1',1),(33,23,'2026-07-30 06:14:48.538','::1','curl/8.7.1',1),(34,23,'2026-07-30 06:15:26.606','::1','curl/8.7.1',1),(35,23,'2026-07-30 06:16:28.056','::1','curl/8.7.1',1),(36,23,'2026-07-30 06:16:42.809','::1','curl/8.7.1',1),(37,23,'2026-07-30 07:02:10.218','::1','curl/8.7.1',1),(38,23,'2026-07-31 04:58:19.873','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(40,23,'2026-08-01 05:06:43.762','::1','curl/8.7.1',0),(41,23,'2026-08-01 05:08:13.955','::1','curl/8.7.1',1),(42,23,'2026-08-01 05:54:36.671','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(43,23,'2026-08-01 05:56:04.887','::1','curl/8.7.1',1),(44,23,'2026-08-01 05:58:17.345','::1','Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',1),(45,23,'2026-08-01 05:59:03.612','::1','Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',1),(46,23,'2026-08-01 06:01:56.355','::1','curl/8.7.1',1),(47,23,'2026-08-01 06:02:06.592','::1','Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',1),(48,23,'2026-08-01 06:02:52.711','::1','Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',1),(49,23,'2026-08-01 06:18:52.830','::1','Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',1),(50,23,'2026-08-01 06:19:17.556','::1','curl/8.7.1',1),(51,23,'2026-08-01 06:25:10.373','::ffff:192.168.1.2','Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',1),(52,23,'2026-08-01 06:31:41.996','::ffff:192.168.1.4','Mozilla/5.0 (iPhone; CPU iPhone OS 27_0_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1',1),(53,23,'2026-08-01 06:31:55.807','::ffff:192.168.1.2','Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',1),(54,23,'2026-08-01 06:32:59.486','::ffff:192.168.1.4','Mozilla/5.0 (iPhone; CPU iPhone OS 27_0_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1',1),(55,31,'2026-08-01 14:45:08.138','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',0),(56,31,'2026-08-01 14:45:10.524','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(57,23,'2026-08-01 14:50:00.418','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(58,32,'2026-08-01 15:12:13.181','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(59,23,'2026-08-01 15:31:22.163','::ffff:192.168.0.111','Mozilla/5.0 (iPhone; CPU iPhone OS 27_0_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/150.0.7871.113 Mobile/15E148 Safari/604.1',1),(60,23,'2026-08-02 03:23:59.082','::ffff:192.168.1.2','Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',1),(61,23,'2026-08-02 03:24:13.289','::ffff:192.168.1.2','Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',1),(62,23,'2026-08-02 03:24:32.520','::1','Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',1),(63,23,'2026-08-02 03:45:53.828','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.0.0 Safari/537.36',1),(64,23,'2026-08-02 03:51:13.370','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(65,34,'2026-08-02 04:02:02.451','::1','curl/8.7.1',1),(66,35,'2026-08-02 04:02:02.761','::1','curl/8.7.1',1),(67,34,'2026-08-02 04:02:20.458','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.0.0 Safari/537.36',1),(68,35,'2026-08-02 04:02:29.352','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.0.0 Safari/537.36',1),(69,34,'2026-08-02 04:02:59.825','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(70,35,'2026-08-02 04:03:31.076','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(71,34,'2026-08-02 04:07:09.297','::1','curl/8.7.1',1),(72,35,'2026-08-02 04:07:09.608','::1','curl/8.7.1',1),(73,35,'2026-08-02 04:07:18.241','::1','curl/8.7.1',1),(74,35,'2026-08-02 04:08:34.941','::1','curl/8.7.1',1),(75,23,'2026-08-02 04:10:42.830','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(76,23,'2026-08-02 04:10:53.405','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(77,23,'2026-08-02 04:12:01.662','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(78,23,'2026-08-02 04:12:54.711','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(79,34,'2026-08-02 04:13:00.044','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(80,34,'2026-08-02 04:13:04.461','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(81,23,'2026-08-02 04:19:45.596','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(82,23,'2026-08-02 04:20:00.080','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(83,34,'2026-08-02 04:20:06.796','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(84,23,'2026-08-02 04:20:21.527','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(85,35,'2026-08-02 04:22:59.028','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(86,34,'2026-08-02 04:23:14.845','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1),(87,34,'2026-08-02 04:25:48.971','::1','curl/8.7.1',1),(88,35,'2026-08-02 04:25:49.194','::1','curl/8.7.1',1),(89,23,'2026-08-02 04:25:49.378','::1','curl/8.7.1',1),(90,34,'2026-08-02 04:25:58.710','::1','curl/8.7.1',1),(91,34,'2026-08-02 04:26:03.701','::1','curl/8.7.1',1),(92,23,'2026-08-02 04:45:05.471','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(93,23,'2026-08-02 04:45:47.051','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(94,23,'2026-08-02 04:47:12.051','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(95,23,'2026-08-02 04:47:23.014','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1),(96,34,'2026-08-02 04:49:17.868','::1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/131.0.6778.33 Safari/537.36',1);
/*!40000 ALTER TABLE `LoginHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_settings`
--

DROP TABLE IF EXISTS `payment_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `branchId` int DEFAULT NULL,
  `merchantName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `upiId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qrEnabled` tinyint(1) NOT NULL DEFAULT '1',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PaymentSettings_companyId_branchId_key` (`companyId`,`branchId`),
  KEY `PaymentSettings_branchId_fkey` (`branchId`),
  KEY `PaymentSettings_createdByUserId_fkey` (`createdByUserId`),
  KEY `PaymentSettings_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `PaymentSettings_branchId_fkey` FOREIGN KEY (`branchId`) REFERENCES `branch` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `PaymentSettings_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `PaymentSettings_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `PaymentSettings_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_settings`
--

LOCK TABLES `payment_settings` WRITE;
/*!40000 ALTER TABLE `payment_settings` DISABLE KEYS */;
INSERT INTO `payment_settings` VALUES (3,6,NULL,'Pratap','pratapdraju-3@okicici',1,1,23,NULL,'2026-07-31 06:02:55.598','2026-07-31 06:02:55.598');
/*!40000 ALTER TABLE `payment_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Permission`
--

DROP TABLE IF EXISTS `Permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Permission`
--

LOCK TABLES `Permission` WRITE;
/*!40000 ALTER TABLE `Permission` DISABLE KEYS */;
INSERT INTO `Permission` VALUES (27,'Dashboard:access','Dashboard','2026-07-30 04:12:03.462','2026-07-30 04:12:03.462'),(28,'Billing:access','Billing','2026-07-30 04:12:03.464','2026-07-30 04:12:03.464'),(29,'View Bill:access','View Bill','2026-07-30 04:12:03.466','2026-07-30 04:12:03.466'),(30,'Inventory:access','Inventory','2026-07-30 04:12:03.468','2026-07-30 04:12:03.468'),(31,'Master:access','Master','2026-07-30 04:12:03.470','2026-07-30 04:12:03.470'),(32,'Reports:access','Reports','2026-07-30 04:12:03.472','2026-07-30 04:12:03.472'),(33,'Admin:access','Admin','2026-07-30 04:12:03.474','2026-07-30 04:12:03.474'),(34,'Production:access','Production','2026-07-30 04:12:03.476','2026-07-30 04:12:03.476'),(35,'Sales:access','Sales','2026-07-30 04:12:03.479','2026-07-30 04:12:03.479'),(36,'WhatsApp:access','WhatsApp','2026-07-30 04:12:03.480','2026-07-30 04:12:03.480'),(37,'Events:access','Events','2026-07-30 04:12:03.481','2026-07-30 04:12:03.481'),(38,'Cash Flow:access','Cash Flow','2026-07-30 04:12:03.482','2026-07-30 04:12:03.482'),(39,'Accounting:access','Accounting','2026-07-30 04:12:03.483','2026-07-30 04:12:03.483'),(40,'GST Management:access','GST Management','2026-07-30 04:30:14.246','2026-07-30 04:30:14.246');
/*!40000 ALTER TABLE `Permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `print_template`
--

DROP TABLE IF EXISTS `print_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `print_template` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `templateName` varchar(255) NOT NULL,
  `templateType` varchar(50) DEFAULT 'BILL',
  `isDefault` tinyint(1) DEFAULT '0',
  `useDynamicPrint` tinyint(1) DEFAULT '1',
  `showLogo` tinyint(1) DEFAULT '0',
  `logoUrl` text,
  `logoSize` varchar(20) DEFAULT 'MEDIUM',
  `logoAlignment` varchar(20) DEFAULT 'CENTER',
  `footerMessage` text,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_template`
--

LOCK TABLES `print_template` WRITE;
/*!40000 ALTER TABLE `print_template` DISABLE KEYS */;
INSERT INTO `print_template` VALUES (1,6,'Default Bill','BILL',1,1,0,NULL,'MEDIUM','CENTER','Thank you. Visit again.','2026-07-30 10:51:46','2026-07-30 10:51:46');
/*!40000 ALTER TABLE `print_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `print_template_field`
--

DROP TABLE IF EXISTS `print_template_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `print_template_field` (
  `id` int NOT NULL AUTO_INCREMENT,
  `templateId` int NOT NULL,
  `fieldKey` varchar(100) NOT NULL,
  `label` varchar(255) NOT NULL,
  `visible` tinyint(1) DEFAULT '1',
  `bold` tinyint(1) DEFAULT '0',
  `fontSize` int DEFAULT '10',
  `alignment` varchar(20) DEFAULT 'LEFT',
  `displayOrder` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templateId` (`templateId`),
  CONSTRAINT `print_template_field_ibfk_1` FOREIGN KEY (`templateId`) REFERENCES `print_template` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_template_field`
--

LOCK TABLES `print_template_field` WRITE;
/*!40000 ALTER TABLE `print_template_field` DISABLE KEYS */;
INSERT INTO `print_template_field` VALUES (1,1,'branchName','Branch Name',1,1,12,'CENTER',0),(2,1,'address1','Address Line 1',1,0,9,'CENTER',1),(3,1,'address2','Address Line 2',1,0,9,'CENTER',2),(4,1,'gstNumber','GST Number',1,0,9,'CENTER',3),(5,1,'phoneNumber','Phone Number',1,0,9,'CENTER',4),(6,1,'invoiceNumber','Invoice Number',1,1,11,'CENTER',5),(7,1,'invoiceDate','Invoice Date',1,0,9,'LEFT',6),(8,1,'cashier','Cashier',1,0,9,'LEFT',7),(9,1,'customer','Customer',1,0,9,'LEFT',8),(10,1,'orderType','Order Type',1,0,9,'LEFT',9),(11,1,'itemName','Item Name',1,0,9,'LEFT',10),(12,1,'quantity','Quantity',1,0,9,'CENTER',11),(13,1,'rate','Rate',1,0,9,'RIGHT',12),(14,1,'amount','Amount',1,0,9,'RIGHT',13),(15,1,'discount','Discount',1,0,9,'RIGHT',14),(16,1,'tax','Tax',1,0,9,'RIGHT',15),(17,1,'subtotal','Sub Total',1,0,10,'RIGHT',16),(18,1,'grandTotal','Grand Total',1,1,11,'RIGHT',17),(19,1,'paymentMode','Payment Mode',1,0,9,'LEFT',18);
/*!40000 ALTER TABLE `print_template_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `productCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hsnCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchasePrice` decimal(10,2) NOT NULL,
  `sellingPrice` decimal(10,2) NOT NULL,
  `gstMasterId` int NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `billLock` tinyint(1) NOT NULL DEFAULT '0',
  `billLockedAt` datetime(3) DEFAULT NULL,
  `billLockedByUserId` int DEFAULT NULL,
  `onlineLock` tinyint(1) NOT NULL DEFAULT '0',
  `onlineLockedAt` datetime(3) DEFAULT NULL,
  `onlineLockedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `companyId` int NOT NULL DEFAULT '1',
  `hsnSacId` int DEFAULT NULL,
  `gstApplicable` tinyint(1) NOT NULL DEFAULT '1',
  `currentStock` decimal(10,2) NOT NULL DEFAULT '0.00',
  `minimumStock` decimal(10,2) NOT NULL DEFAULT '0.00',
  `maximumStock` decimal(10,2) NOT NULL DEFAULT '0.00',
  `reorderLevel` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `product_gstMasterId_fkey` (`gstMasterId`),
  KEY `product_companyId_idx` (`companyId`),
  KEY `Product_hsnSacId_idx` (`hsnSacId`),
  KEY `Product_billLockedByUserId_fkey` (`billLockedByUserId`),
  KEY `Product_onlineLockedByUserId_fkey` (`onlineLockedByUserId`),
  CONSTRAINT `Product_billLockedByUserId_fkey` FOREIGN KEY (`billLockedByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `product_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `product_gstMasterId_fkey` FOREIGN KEY (`gstMasterId`) REFERENCES `gst_master` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Product_onlineLockedByUserId_fkey` FOREIGN KEY (`onlineLockedByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (16,'Rice',NULL,NULL,'8907657628309',NULL,'Food','KG',200.00,200.00,7,1,0,NULL,NULL,0,NULL,NULL,'2026-07-30 07:13:58.645','2026-08-01 14:28:48.399',6,NULL,1,7.00,0.00,0.00,0.00),(17,'Milk',NULL,NULL,NULL,NULL,'Food','Ltr',34.00,34.00,7,1,0,NULL,NULL,0,NULL,NULL,'2026-07-30 07:14:14.701','2026-07-31 06:01:28.812',6,NULL,1,0.00,0.00,0.00,0.00);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_conversion`
--

DROP TABLE IF EXISTS `production_conversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_conversion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `productId` int NOT NULL,
  `baseQty` decimal(12,3) NOT NULL,
  `baseUnit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `portionQty` decimal(12,3) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `production_conversion_companyId_productId_key` (`companyId`,`productId`),
  KEY `production_conversion_createdByUserId_idx` (`createdByUserId`),
  KEY `production_conversion_updatedByUserId_idx` (`updatedByUserId`),
  KEY `production_conversion_productId_fkey` (`productId`),
  CONSTRAINT `production_conversion_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_conversion_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `production_conversion_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_conversion_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_conversion`
--

LOCK TABLES `production_conversion` WRITE;
/*!40000 ALTER TABLE `production_conversion` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_conversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_in`
--

DROP TABLE IF EXISTS `production_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_in` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `prodNo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productionCategory` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productionTransferNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `planningNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `indentNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numberOfProducts` int NOT NULL DEFAULT '0',
  `grandTotal` decimal(12,2) NOT NULL,
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `production_in_companyId_prodNo_key` (`companyId`,`prodNo`),
  KEY `production_in_createdAt_idx` (`createdAt`),
  KEY `production_in_createdByUserId_fkey` (`createdByUserId`),
  KEY `production_in_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `production_in_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_in_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `production_in_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_in`
--

LOCK TABLES `production_in` WRITE;
/*!40000 ALTER TABLE `production_in` DISABLE KEYS */;
INSERT INTO `production_in` VALUES (2,6,'PIN000001','Morning Session',NULL,NULL,NULL,NULL,1,34.00,23,23,'2026-07-31 07:25:43.942','2026-07-31 07:25:43.942');
/*!40000 ALTER TABLE `production_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_in_item`
--

DROP TABLE IF EXISTS `production_in_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_in_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productionInId` int NOT NULL,
  `productId` int NOT NULL,
  `quantity` decimal(12,3) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `totalPrice` decimal(12,2) NOT NULL,
  `companyId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `production_in_item_productId_idx` (`productId`),
  KEY `production_in_item_companyId_idx` (`companyId`),
  KEY `production_in_item_productionInId_fkey` (`productionInId`),
  CONSTRAINT `production_in_item_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_in_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_in_item_productionInId_fkey` FOREIGN KEY (`productionInId`) REFERENCES `production_in` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_in_item`
--

LOCK TABLES `production_in_item` WRITE;
/*!40000 ALTER TABLE `production_in_item` DISABLE KEYS */;
INSERT INTO `production_in_item` VALUES (4,2,17,1.000,34.00,34.00,6);
/*!40000 ALTER TABLE `production_in_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_mapping`
--

DROP TABLE IF EXISTS `production_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_mapping` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `mappingType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Production',
  `itemId` int NOT NULL,
  `productId` int NOT NULL,
  `quantity` decimal(12,3) NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchasePrice` decimal(12,2) NOT NULL DEFAULT '0.00',
  `cost` decimal(12,2) NOT NULL DEFAULT '0.00',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `production_mapping_companyId_itemId_productId_key` (`companyId`,`itemId`,`productId`),
  KEY `production_mapping_productId_idx` (`productId`),
  KEY `production_mapping_itemId_idx` (`itemId`),
  KEY `production_mapping_createdByUserId_idx` (`createdByUserId`),
  KEY `production_mapping_updatedByUserId_idx` (`updatedByUserId`),
  CONSTRAINT `production_mapping_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_mapping_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `production_mapping_itemId_fkey` FOREIGN KEY (`itemId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_mapping_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_mapping_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_mapping`
--

LOCK TABLES `production_mapping` WRITE;
/*!40000 ALTER TABLE `production_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_out`
--

DROP TABLE IF EXISTS `production_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_out` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `outNo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productionCategory` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `indentNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branchId` int DEFAULT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numberOfProducts` int NOT NULL DEFAULT '0',
  `grandTotal` decimal(12,2) NOT NULL,
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `production_out_companyId_outNo_key` (`companyId`,`outNo`),
  KEY `production_out_createdAt_idx` (`createdAt`),
  KEY `production_out_branchId_fkey` (`branchId`),
  KEY `production_out_createdByUserId_fkey` (`createdByUserId`),
  KEY `production_out_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `production_out_branchId_fkey` FOREIGN KEY (`branchId`) REFERENCES `branch` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `production_out_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_out_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `production_out_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_out`
--

LOCK TABLES `production_out` WRITE;
/*!40000 ALTER TABLE `production_out` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_out_item`
--

DROP TABLE IF EXISTS `production_out_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_out_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productionOutId` int NOT NULL,
  `productId` int NOT NULL,
  `quantity` decimal(12,3) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `totalPrice` decimal(12,2) NOT NULL,
  `companyId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `production_out_item_productId_idx` (`productId`),
  KEY `production_out_item_companyId_idx` (`companyId`),
  KEY `production_out_item_productionOutId_fkey` (`productionOutId`),
  CONSTRAINT `production_out_item_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_out_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_out_item_productionOutId_fkey` FOREIGN KEY (`productionOutId`) REFERENCES `production_out` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_out_item`
--

LOCK TABLES `production_out_item` WRITE;
/*!40000 ALTER TABLE `production_out_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_out_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_plan`
--

DROP TABLE IF EXISTS `production_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_plan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `planNo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productionCategory` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requestDate` datetime(3) NOT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numberOfProducts` int NOT NULL DEFAULT '0',
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `production_plan_companyId_planNo_key` (`companyId`,`planNo`),
  KEY `production_plan_requestDate_idx` (`requestDate`),
  KEY `production_plan_createdByUserId_fkey` (`createdByUserId`),
  KEY `production_plan_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `production_plan_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_plan_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `production_plan_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_plan`
--

LOCK TABLES `production_plan` WRITE;
/*!40000 ALTER TABLE `production_plan` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_plan_item`
--

DROP TABLE IF EXISTS `production_plan_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_plan_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productionPlanId` int NOT NULL,
  `productId` int NOT NULL,
  `quantity` decimal(12,3) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `totalPrice` decimal(12,2) NOT NULL,
  `companyId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `production_plan_item_productId_idx` (`productId`),
  KEY `production_plan_item_productionPlanId_fkey` (`productionPlanId`),
  KEY `production_plan_item_companyId_idx` (`companyId`),
  CONSTRAINT `production_plan_item_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_plan_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `production_plan_item_productionPlanId_fkey` FOREIGN KEY (`productionPlanId`) REFERENCES `production_plan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_plan_item`
--

LOCK TABLES `production_plan_item` WRITE;
/*!40000 ALTER TABLE `production_plan_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_plan_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_invoice`
--

DROP TABLE IF EXISTS `purchase_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendorInvoiceNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `companyId` int NOT NULL,
  `vendorId` int NOT NULL,
  `branchId` int DEFAULT NULL,
  `purchaseOrderId` int DEFAULT NULL,
  `grnId` int DEFAULT NULL,
  `invoiceDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `subtotal` decimal(12,2) NOT NULL,
  `taxAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `grandTotal` decimal(12,2) NOT NULL,
  `paymentStatus` enum('PENDING','PARTIALLY_PAID','PAID') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdByUserId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PurchaseInvoice_companyId_invoiceNumber_key` (`companyId`,`invoiceNumber`),
  KEY `PurchaseInvoice_companyId_idx` (`companyId`),
  KEY `PurchaseInvoice_vendorId_idx` (`vendorId`),
  KEY `PurchaseInvoice_purchaseOrderId_fkey` (`purchaseOrderId`),
  KEY `PurchaseInvoice_grnId_fkey` (`grnId`),
  KEY `PurchaseInvoice_createdByUserId_fkey` (`createdByUserId`),
  CONSTRAINT `PurchaseInvoice_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_invoice`
--

LOCK TABLES `purchase_invoice` WRITE;
/*!40000 ALTER TABLE `purchase_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order`
--

DROP TABLE IF EXISTS `purchase_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `poNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `companyId` int NOT NULL,
  `vendorId` int NOT NULL,
  `branchId` int DEFAULT NULL,
  `orderDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `expectedDelivery` datetime(3) DEFAULT NULL,
  `status` enum('DRAFT','PENDING','APPROVED','PARTIALLY_RECEIVED','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `subtotal` decimal(12,2) NOT NULL,
  `discountAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `taxAmount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `grandTotal` decimal(12,2) NOT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdByUserId` int NOT NULL,
  `approvedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PurchaseOrder_companyId_poNumber_key` (`companyId`,`poNumber`),
  KEY `PurchaseOrder_companyId_idx` (`companyId`),
  KEY `PurchaseOrder_vendorId_idx` (`vendorId`),
  KEY `PurchaseOrder_status_idx` (`status`),
  KEY `PurchaseOrder_createdByUserId_fkey` (`createdByUserId`),
  KEY `PurchaseOrder_approvedByUserId_fkey` (`approvedByUserId`),
  CONSTRAINT `PurchaseOrder_approvedByUserId_fkey` FOREIGN KEY (`approvedByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `PurchaseOrder_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order`
--

LOCK TABLES `purchase_order` WRITE;
/*!40000 ALTER TABLE `purchase_order` DISABLE KEYS */;
INSERT INTO `purchase_order` VALUES (1,'PO000001',6,5,NULL,'2026-07-30 07:19:18.790','2026-07-31 00:00:00.000','APPROVED',4068.00,0.00,203.40,4271.40,NULL,23,23,'2026-07-30 07:19:18.790','2026-07-30 08:47:30.333'),(2,'PO000002',6,5,NULL,'2026-07-30 08:43:04.927','2026-07-31 00:00:00.000','APPROVED',570.00,0.00,28.50,598.50,NULL,23,23,'2026-07-30 08:43:04.927','2026-07-30 08:47:27.726'),(3,'PO000003',6,5,NULL,'2026-07-30 08:51:40.279',NULL,'COMPLETED',4204.00,0.00,210.20,4414.20,NULL,23,23,'2026-07-30 08:51:40.279','2026-07-30 08:59:33.009'),(4,'PO000004',6,5,NULL,'2026-08-01 14:23:14.403',NULL,'DRAFT',200.00,0.00,10.00,210.00,NULL,23,NULL,'2026-08-01 14:23:14.403','2026-08-01 14:23:14.403');
/*!40000 ALTER TABLE `purchase_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_item`
--

DROP TABLE IF EXISTS `purchase_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchaseOrderId` int NOT NULL,
  `productId` int NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `receivedQty` decimal(10,2) NOT NULL DEFAULT '0.00',
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchasePrice` decimal(10,2) NOT NULL,
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `gstPercentage` decimal(5,2) NOT NULL,
  `cgstAmount` decimal(12,2) NOT NULL,
  `sgstAmount` decimal(12,2) NOT NULL,
  `igstAmount` decimal(12,2) NOT NULL,
  `taxAmount` decimal(12,2) NOT NULL,
  `lineTotal` decimal(12,2) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `PurchaseOrderItem_purchaseOrderId_idx` (`purchaseOrderId`),
  KEY `PurchaseOrderItem_productId_idx` (`productId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_item`
--

LOCK TABLES `purchase_order_item` WRITE;
/*!40000 ALTER TABLE `purchase_order_item` DISABLE KEYS */;
INSERT INTO `purchase_order_item` VALUES (1,1,17,2.00,0.00,'Ltr',34.00,0.00,5.00,1.70,1.70,3.40,3.40,71.40,'2026-07-30 07:19:18.793','2026-07-30 07:19:18.793'),(2,1,16,20.00,0.00,'KG',200.00,0.00,5.00,100.00,100.00,200.00,200.00,4200.00,'2026-07-30 07:19:18.793','2026-07-30 07:19:18.793'),(3,2,17,5.00,0.00,'Ltr',34.00,0.00,5.00,4.25,4.25,8.50,8.50,178.50,'2026-07-30 08:43:04.941','2026-07-30 08:43:04.941'),(4,2,16,2.00,0.00,'KG',200.00,0.00,5.00,10.00,10.00,20.00,20.00,420.00,'2026-07-30 08:43:04.941','2026-07-30 08:43:04.941'),(5,3,17,6.00,6.00,'Ltr',34.00,0.00,5.00,5.10,5.10,10.20,10.20,214.20,'2026-07-30 08:51:40.283','2026-07-30 08:59:32.995'),(6,3,16,20.00,20.00,'KG',200.00,0.00,5.00,100.00,100.00,200.00,200.00,4200.00,'2026-07-30 08:51:40.283','2026-07-30 08:59:33.004'),(7,4,16,1.00,0.00,'KG',200.00,0.00,5.00,5.00,5.00,10.00,10.00,210.00,'2026-08-01 14:23:14.405','2026-08-01 14:23:14.405');
/*!40000 ALTER TABLE `purchase_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote`
--

DROP TABLE IF EXISTS `quote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quote` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `quoteNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customerName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quoteDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `expiryDate` datetime(3) DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Draft',
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `taxRate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `discountType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '%',
  PRIMARY KEY (`id`),
  UNIQUE KEY `quote_quoteNumber_key` (`quoteNumber`),
  KEY `quote_companyId_idx` (`companyId`),
  KEY `quote_createdByUserId_fkey` (`createdByUserId`),
  KEY `quote_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `quote_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `quote_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `quote_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote`
--

LOCK TABLES `quote` WRITE;
/*!40000 ALTER TABLE `quote` DISABLE KEYS */;
INSERT INTO `quote` VALUES (3,6,'QT-0001','1002-Omkar Tanti','2026-08-01 00:00:00.000','2026-08-31 00:00:00.000','Sent',10.00,18.00,'Thank you for your business!','Payment due within 30 days\nQuote valid for 30 days',23,23,'2026-08-01 03:39:47.524','2026-08-01 03:39:47.524','%');
/*!40000 ALTER TABLE `quote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quote_item`
--

DROP TABLE IF EXISTS `quote_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quote_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quoteId` int NOT NULL,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hsn` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unitPrice` decimal(12,2) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `quote_item_quoteId_idx` (`quoteId`),
  CONSTRAINT `quote_item_quoteId_fkey` FOREIGN KEY (`quoteId`) REFERENCES `quote` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quote_item`
--

LOCK TABLES `quote_item` WRITE;
/*!40000 ALTER TABLE `quote_item` DISABLE KEYS */;
INSERT INTO `quote_item` VALUES (5,3,'POS Software License','Annual license','8523',1.00,12000.00,12000.00,'2026-08-01 03:39:47.524','2026-08-01 03:39:47.524'),(6,3,'Installation & Setup','On-site','9983',1.00,3000.00,3000.00,'2026-08-01 03:39:47.524','2026-08-01 03:39:47.524');
/*!40000 ALTER TABLE `quote_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restore_history`
--

DROP TABLE IF EXISTS `restore_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restore_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `backupId` int DEFAULT NULL,
  `restoreName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileSize` int NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `tablesRestored` int NOT NULL DEFAULT '0',
  `recordsRestored` int NOT NULL DEFAULT '0',
  `error` text COLLATE utf8mb4_unicode_ci,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `createdByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `restore_history_companyId_idx` (`companyId`),
  KEY `restore_history_createdAt_idx` (`createdAt`),
  KEY `restore_history_createdByUserId_fkey` (`createdByUserId`),
  CONSTRAINT `restore_history_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `restore_history_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restore_history`
--

LOCK TABLES `restore_history` WRITE;
/*!40000 ALTER TABLE `restore_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `restore_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Role`
--

DROP TABLE IF EXISTS `Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Role_name_key` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Role`
--

LOCK TABLES `Role` WRITE;
/*!40000 ALTER TABLE `Role` DISABLE KEYS */;
INSERT INTO `Role` VALUES (10,'Owner','2026-07-30 04:12:03.439','2026-07-30 04:12:03.439'),(11,'Admin','2026-07-30 04:12:03.448','2026-07-30 04:12:03.448'),(12,'Manager','2026-07-30 04:12:03.450','2026-07-30 04:12:03.450'),(13,'Senior Manager','2026-07-30 04:12:03.451','2026-07-30 04:12:03.451'),(14,'Cashier','2026-07-30 04:12:03.454','2026-07-30 04:12:03.454'),(15,'Captain','2026-07-30 04:12:03.456','2026-07-30 04:12:03.456'),(16,'Staff','2026-07-30 04:12:03.457','2026-07-30 04:12:03.457'),(17,'User','2026-07-30 04:12:03.457','2026-07-30 04:12:03.457'),(18,'Driver','2026-07-30 04:12:03.458','2026-07-30 04:12:03.458');
/*!40000 ALTER TABLE `Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RolePermission`
--

DROP TABLE IF EXISTS `RolePermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RolePermission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `roleId` int NOT NULL,
  `permissionId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `RolePermission_roleId_permissionId_key` (`roleId`,`permissionId`),
  KEY `RolePermission_permissionId_fkey` (`permissionId`),
  CONSTRAINT `RolePermission_permissionId_fkey` FOREIGN KEY (`permissionId`) REFERENCES `Permission` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `RolePermission_roleId_fkey` FOREIGN KEY (`roleId`) REFERENCES `Role` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RolePermission`
--

LOCK TABLES `RolePermission` WRITE;
/*!40000 ALTER TABLE `RolePermission` DISABLE KEYS */;
INSERT INTO `RolePermission` VALUES (63,10,27,'2026-07-30 04:12:03.485'),(64,10,28,'2026-07-30 04:12:03.487'),(65,10,29,'2026-07-30 04:12:03.489'),(66,10,30,'2026-07-30 04:12:03.491'),(67,10,31,'2026-07-30 04:12:03.493'),(68,10,32,'2026-07-30 04:12:03.494'),(69,10,33,'2026-07-30 04:12:03.496'),(70,10,34,'2026-07-30 04:12:03.497'),(71,10,35,'2026-07-30 04:12:03.498'),(72,10,36,'2026-07-30 04:12:03.499'),(73,10,37,'2026-07-30 04:12:03.501'),(74,10,38,'2026-07-30 04:12:03.502'),(75,10,39,'2026-07-30 04:12:03.503'),(76,11,27,'2026-07-30 04:12:03.504'),(77,11,28,'2026-07-30 04:12:03.505'),(78,11,29,'2026-07-30 04:12:03.506'),(79,11,30,'2026-07-30 04:12:03.507'),(80,11,31,'2026-07-30 04:12:03.509'),(81,11,32,'2026-07-30 04:12:03.511'),(82,11,33,'2026-07-30 04:12:03.513'),(83,11,34,'2026-07-30 04:12:03.515'),(84,11,35,'2026-07-30 04:12:03.516'),(85,11,36,'2026-07-30 04:12:03.517'),(86,11,37,'2026-07-30 04:12:03.519'),(87,11,38,'2026-07-30 04:12:03.521'),(88,11,39,'2026-07-30 04:12:03.522'),(89,12,27,'2026-07-30 04:12:03.523'),(90,12,28,'2026-07-30 04:12:03.524'),(91,12,29,'2026-07-30 04:12:03.524'),(92,12,30,'2026-07-30 04:12:03.525'),(93,12,31,'2026-07-30 04:12:03.526'),(94,12,32,'2026-07-30 04:12:03.527'),(95,12,34,'2026-07-30 04:12:03.528'),(96,12,35,'2026-07-30 04:12:03.529'),(97,12,36,'2026-07-30 04:12:03.530'),(98,12,37,'2026-07-30 04:12:03.532'),(99,12,38,'2026-07-30 04:12:03.533'),(100,12,39,'2026-07-30 04:12:03.535'),(101,13,27,'2026-07-30 04:12:03.536'),(102,13,28,'2026-07-30 04:12:03.537'),(103,13,29,'2026-07-30 04:12:03.538'),(104,13,30,'2026-07-30 04:12:03.539'),(105,13,31,'2026-07-30 04:12:03.540'),(106,13,32,'2026-07-30 04:12:03.542'),(107,13,34,'2026-07-30 04:12:03.542'),(108,13,35,'2026-07-30 04:12:03.544'),(109,13,36,'2026-07-30 04:12:03.546'),(110,13,37,'2026-07-30 04:12:03.546'),(111,13,38,'2026-07-30 04:12:03.548'),(112,13,39,'2026-07-30 04:12:03.551'),(113,14,27,'2026-07-30 04:12:03.552'),(114,14,28,'2026-07-30 04:12:03.554'),(115,14,29,'2026-07-30 04:12:03.556'),(116,15,27,'2026-07-30 04:12:03.557'),(117,15,29,'2026-07-30 04:12:03.559'),(118,16,27,'2026-07-30 04:12:03.560'),(119,16,28,'2026-07-30 04:12:03.562'),(120,17,27,'2026-07-30 04:12:03.563'),(121,17,28,'2026-07-30 04:12:03.564'),(122,17,29,'2026-07-30 04:12:03.564'),(123,17,32,'2026-07-30 04:12:03.565'),(124,18,27,'2026-07-30 04:12:03.566'),(125,18,29,'2026-07-30 04:12:03.567'),(126,10,40,'2026-07-30 04:30:14.336'),(127,11,40,'2026-07-30 04:30:14.366'),(128,12,40,'2026-07-30 04:30:14.410'),(129,13,40,'2026-07-30 04:30:14.445');
/*!40000 ALTER TABLE `RolePermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_audit`
--

DROP TABLE IF EXISTS `stock_audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_audit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `auditNumber` varchar(191) NOT NULL,
  `companyId` int NOT NULL,
  `branchId` int DEFAULT NULL,
  `auditType` varchar(191) NOT NULL DEFAULT 'FULL',
  `auditDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `auditor` varchar(191) NOT NULL,
  `remarks` varchar(191) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'DRAFT',
  `createdByUserId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_audit_auditNumber_companyId_key` (`auditNumber`,`companyId`),
  KEY `stock_audit_companyId_fkey` (`companyId`),
  KEY `stock_audit_createdByUserId_fkey` (`createdByUserId`),
  CONSTRAINT `stock_audit_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `stock_audit_ibfk_2` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_audit`
--

LOCK TABLES `stock_audit` WRITE;
/*!40000 ALTER TABLE `stock_audit` DISABLE KEYS */;
INSERT INTO `stock_audit` VALUES (1,'SA000001',6,NULL,'FULL','2026-07-30 00:00:00.000','Yuva',NULL,'COMPLETED',23,'2026-07-30 09:31:26.461','2026-07-30 09:31:26.461');
/*!40000 ALTER TABLE `stock_audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_audit_item`
--

DROP TABLE IF EXISTS `stock_audit_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_audit_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `stockAuditId` int NOT NULL,
  `productId` int NOT NULL,
  `systemStock` decimal(10,2) NOT NULL,
  `physicalStock` decimal(10,2) NOT NULL,
  `difference` decimal(10,2) NOT NULL,
  `adjustmentType` varchar(191) NOT NULL,
  `remarks` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_audit_item_stockAuditId_fkey` (`stockAuditId`),
  KEY `stock_audit_item_productId_fkey` (`productId`),
  CONSTRAINT `stock_audit_item_ibfk_1` FOREIGN KEY (`stockAuditId`) REFERENCES `stock_audit` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `stock_audit_item_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_audit_item`
--

LOCK TABLES `stock_audit_item` WRITE;
/*!40000 ALTER TABLE `stock_audit_item` DISABLE KEYS */;
INSERT INTO `stock_audit_item` VALUES (1,1,17,0.00,6.00,6.00,'EXCESS',NULL,'2026-07-30 09:31:26.468','2026-07-30 09:31:26.468'),(2,1,16,0.00,20.00,20.00,'EXCESS',NULL,'2026-07-30 09:31:26.478','2026-07-30 09:31:26.478');
/*!40000 ALTER TABLE `stock_audit_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_out`
--

DROP TABLE IF EXISTS `stock_out`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_out` (
  `id` int NOT NULL AUTO_INCREMENT,
  `stockOutNumber` varchar(191) NOT NULL,
  `companyId` int NOT NULL,
  `branchId` int DEFAULT NULL,
  `stockOutType` enum('PRODUCTION','DAMAGE','ADJUSTMENT','BRANCH_TRANSFER','OTHER') NOT NULL DEFAULT 'PRODUCTION',
  `referenceNumber` varchar(191) DEFAULT NULL,
  `stockOutDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('PENDING','COMPLETED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `notes` text,
  `createdByUserId` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_out_companyId_stockOutNumber_key` (`companyId`,`stockOutNumber`),
  KEY `stock_out_companyId_idx` (`companyId`),
  KEY `stock_out_createdByUserId_idx` (`createdByUserId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_out`
--

LOCK TABLES `stock_out` WRITE;
/*!40000 ALTER TABLE `stock_out` DISABLE KEYS */;
INSERT INTO `stock_out` VALUES (1,'SO000001',6,NULL,'PRODUCTION',NULL,'2026-07-30 09:16:09','COMPLETED',NULL,23,'2026-07-30 09:16:09','2026-07-30 09:16:09');
/*!40000 ALTER TABLE `stock_out` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_out_item`
--

DROP TABLE IF EXISTS `stock_out_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_out_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `stockOutId` int NOT NULL,
  `productId` int NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `stock_out_item_stockOutId_idx` (`stockOutId`),
  KEY `stock_out_item_productId_idx` (`productId`),
  CONSTRAINT `stock_out_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `stock_out_item_stockOutId_fkey` FOREIGN KEY (`stockOutId`) REFERENCES `stock_out` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_out_item`
--

LOCK TABLES `stock_out_item` WRITE;
/*!40000 ALTER TABLE `stock_out_item` DISABLE KEYS */;
INSERT INTO `stock_out_item` VALUES (1,1,17,6.00,34.00,204.00,'2026-07-30 09:16:09','2026-07-30 09:16:09'),(2,1,16,20.00,200.00,4000.00,'2026-07-30 09:16:09','2026-07-30 09:16:09');
/*!40000 ALTER TABLE `stock_out_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `admissionNumber` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `dateOfBirth` date DEFAULT NULL,
  `mobileNumber` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `class` varchar(255) DEFAULT NULL,
  `section` varchar(255) DEFAULT NULL,
  `academicYear` varchar(50) DEFAULT NULL,
  `rollNumber` varchar(50) DEFAULT NULL,
  `parentName` varchar(255) DEFAULT NULL,
  `parentMobile` varchar(50) DEFAULT NULL,
  `parentEmail` varchar(255) DEFAULT NULL,
  `address` text,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) NOT NULL DEFAULT 'India',
  `pincode` varchar(20) DEFAULT NULL,
  `remarks` text,
  `block` varchar(255) DEFAULT NULL,
  `roomNo` varchar(50) DEFAULT NULL,
  `wallet` decimal(10,2) NOT NULL DEFAULT '0.00',
  `fingerPrint` text,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdByUserId` int NOT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_student_roll` (`companyId`,`rollNumber`),
  KEY `createdByUserId` (`createdByUserId`),
  KEY `updatedByUserId` (`updatedByUserId`),
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`),
  CONSTRAINT `student_ibfk_2` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`),
  CONSTRAINT `student_ibfk_3` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit`
--

DROP TABLE IF EXISTS `unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `unitName` varchar(100) NOT NULL,
  `shortName` varchar(50) NOT NULL,
  `description` text,
  `displayOrder` int DEFAULT '0',
  `isActive` tinyint(1) DEFAULT '1',
  `createdByUserId` int NOT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_unit_name` (`companyId`,`unitName`),
  UNIQUE KEY `unique_short_name` (`companyId`,`shortName`),
  KEY `idx_company` (`companyId`),
  KEY `fk_unit_user` (`createdByUserId`),
  CONSTRAINT `fk_unit_company` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`),
  CONSTRAINT `fk_unit_user` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit`
--

LOCK TABLES `unit` WRITE;
/*!40000 ALTER TABLE `unit` DISABLE KEYS */;
INSERT INTO `unit` VALUES (1,6,'KILOGRAM','KG',NULL,0,1,23,'2026-07-31 03:03:53','2026-07-31 03:03:53'),(2,6,'LITRE','LTR',NULL,0,1,23,'2026-07-31 03:03:53','2026-07-31 03:03:53'),(3,6,'GRAM','GM',NULL,0,1,23,'2026-07-31 03:03:53','2026-07-31 03:03:53'),(4,6,'PIECE','PCS',NULL,0,1,23,'2026-07-31 03:03:53','2026-07-31 03:03:53'),(5,6,'NUMBER','NOS',NULL,0,1,23,'2026-07-31 03:03:53','2026-07-31 03:03:53'),(6,6,'PACK','PACK',NULL,0,1,23,'2026-07-31 03:03:53','2026-07-31 03:03:53');
/*!40000 ALTER TABLE `unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roleId` int NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `mobileNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `defaultCompanyId` int NOT NULL DEFAULT '1',
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`),
  UNIQUE KEY `User_username_key` (`username`),
  KEY `User_roleId_fkey` (`roleId`),
  KEY `User_defaultCompanyId_idx` (`defaultCompanyId`),
  CONSTRAINT `User_defaultCompanyId_fkey` FOREIGN KEY (`defaultCompanyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `User_roleId_fkey` FOREIGN KEY (`roleId`) REFERENCES `Role` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (23,'$2b$10$hB0gct27KguXcmJJoyIBX.HM6uR8B7CNR23gSmmbLXmKMf0Ioj7eG','Super Admin',10,1,'2026-07-30 04:12:03.688','2026-07-30 04:12:03.688','admin@billora.com','9876543210',6,'superadmin'),(30,'$2b$10$t1l8Uvo0bMeFFX8GIcVaP.JS6iCxFCW3NmfotGoG/VAIeaLajJHZa','Yuvanth Veluru',14,1,'2026-07-30 04:42:01.251','2026-07-30 04:42:01.251','yuvanth@billora.local',NULL,6,'yuvanth'),(31,'$2b$10$uc47fxqk1IU7c.fkkrhLjOGaNuOZVfEJFRLARUlFcQwSry7hUu872','Pratap D',14,1,'2026-08-01 14:44:51.706','2026-08-01 14:44:51.706','pratap@billora.local',NULL,6,'pratap'),(32,'$2b$10$.bSzyoLVxyG/qU4f3jUOLOGFtGh0Ixb3X3oc8Y60AHl8pqSwqf8EW','Yuvanth VEluru',11,1,'2026-08-01 15:11:18.001','2026-08-01 15:11:18.001','yuva@billora.local',NULL,6,'yuva'),(33,'$2b$10$xv1L3CXoMM4HmXydMa2cfOZRoKN4eEir8LdDlqACOYiIxrkhazg6q','Madhan R',11,1,'2026-08-01 15:11:51.576','2026-08-01 15:11:51.576','madhan@billora.local',NULL,6,'madhan'),(34,'$2b$10$wGgfot7c2pGyzKKkhaRCK.BKlfHIIY7mVJ89jN9KsSE0eJTUa3gxi','Ocean View Admin',11,1,'2026-08-02 04:01:56.550','2026-08-02 04:08:34.719','oceanview@billora.local',NULL,7,'oceanview'),(35,'$2b$10$SsjzsKTd9bFvbcVmre0NI.7aKz9Mm1ce3J8lPKnzucw8wkDT4vd4a','Green Leaf Admin',11,1,'2026-08-02 04:01:56.693','2026-08-02 04:01:56.693','greenleaf@billora.local',NULL,8,'greenleaf'),(36,'$2b$10$EP9T9VCtVn0GEP8DjxUOg.DFudrosAcVRPmqfHdhhX5zpOLus46Qa','Test Cross User',11,0,'2026-08-02 04:07:18.053','2026-08-02 04:08:34.599','testcross@billora.local',NULL,8,'testcross'),(37,'$2b$10$dwt4CqfARgpQ7W0ZMA72V.FsmgbtaUxLCxYyWxP3LO1p5Cn/quyJa','UiCross',11,0,'2026-08-02 04:12:57.922','2026-08-02 04:13:02.394','uicross@billora.local',NULL,7,'uicross'),(38,'$2b$10$r1f/R3ebKDvxlVR12Sflaee8Hbu/Y0/PvaHDqQlM4NlZzdTC0Ub76','Test Cashier',14,0,'2026-08-02 04:25:58.889','2026-08-02 04:26:03.741','testcashier@billora.local',NULL,7,'testcashier');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserCompany`
--

DROP TABLE IF EXISTS `UserCompany`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserCompany` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `companyId` int NOT NULL,
  `roleId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserCompany_userId_companyId_key` (`userId`,`companyId`),
  KEY `UserCompany_companyId_idx` (`companyId`),
  KEY `UserCompany_roleId_idx` (`roleId`),
  CONSTRAINT `UserCompany_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `UserCompany_roleId_fkey` FOREIGN KEY (`roleId`) REFERENCES `Role` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `UserCompany_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserCompany`
--

LOCK TABLES `UserCompany` WRITE;
/*!40000 ALTER TABLE `UserCompany` DISABLE KEYS */;
INSERT INTO `UserCompany` VALUES (29,23,6,10,'2026-07-30 04:12:03.690'),(36,30,6,14,'2026-07-30 04:42:01.255'),(37,31,6,14,'2026-08-01 14:44:51.708'),(38,32,6,11,'2026-08-01 15:11:18.012'),(39,33,6,11,'2026-08-01 15:11:51.578'),(40,23,7,10,'2026-08-02 03:54:27.536'),(41,23,8,10,'2026-08-02 03:54:27.590'),(42,34,7,11,'2026-08-02 04:01:56.553'),(43,35,8,11,'2026-08-02 04:01:56.695');
/*!40000 ALTER TABLE `UserCompany` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor`
--

DROP TABLE IF EXISTS `vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `vendorCode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendorName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contactPerson` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobileNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alternateMobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gstNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `panNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stateCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'India',
  `postalCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentTerms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creditLimit` decimal(12,2) NOT NULL DEFAULT '0.00',
  `openingBalance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `currentBalance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Vendor_companyId_vendorCode_key` (`companyId`,`vendorCode`),
  KEY `Vendor_companyId_idx` (`companyId`),
  KEY `vendor_createdByUserId_idx` (`createdByUserId`),
  KEY `vendor_updatedByUserId_idx` (`updatedByUserId`),
  CONSTRAINT `vendor_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `vendor_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor`
--

LOCK TABLES `vendor` WRITE;
/*!40000 ALTER TABLE `vendor` DISABLE KEYS */;
INSERT INTO `vendor` VALUES (1,6,'VEND0001','Fresh Foods Suppliers','Rajesh Kumar','9876543210',NULL,NULL,'33BBBBB1234F1Z5',NULL,NULL,NULL,'Tamil Nadu','33','India',NULL,'30 Days',500000.00,0.00,0.00,1,NULL,NULL,'2026-07-30 04:58:33.603','2026-07-31 04:57:48.927'),(2,6,'VEND0002','Metro Wholesale','Priya Sharma','9876543211',NULL,NULL,'27CCCCC1234F1Z5',NULL,NULL,NULL,'Maharashtra','27','India',NULL,'15 Days',300000.00,0.00,0.00,1,NULL,NULL,'2026-07-30 04:58:33.607','2026-07-31 04:57:39.883'),(3,6,'VEND0003','Green Valley Traders','Arun Patel','9876543212',NULL,NULL,'24DDDDD1234F1Z5',NULL,NULL,NULL,'Gujarat','24','India',NULL,'Credit',200000.00,0.00,0.00,1,NULL,NULL,'2026-07-30 04:58:33.610','2026-07-30 04:58:33.610'),(4,6,'VEND0004','Yuvanth',NULL,'7010991925',NULL,'yuvanthvcsc@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,0.00,0.00,0.00,1,NULL,NULL,'2026-07-30 06:16:28.115','2026-07-30 06:16:28.115'),(5,6,'VEND0005','Yuvanth','9677192579','9677192579',NULL,'yuvanthvcsc@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,'India',NULL,NULL,0.00,0.00,0.00,1,NULL,NULL,'2026-07-30 06:17:33.533','2026-07-30 06:17:33.533');
/*!40000 ALTER TABLE `vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor_branch_mapping`
--

DROP TABLE IF EXISTS `vendor_branch_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendor_branch_mapping` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `vendorId` int NOT NULL,
  `branchId` int NOT NULL,
  `status` varchar(20) DEFAULT 'ACTIVE',
  `effectiveFrom` datetime DEFAULT NULL,
  `effectiveTo` datetime DEFAULT NULL,
  `remarks` text,
  `isActive` tinyint(1) DEFAULT '1',
  `createdByUserId` int NOT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_vendor_branch` (`companyId`,`vendorId`,`branchId`),
  KEY `idx_company` (`companyId`),
  KEY `idx_vendor` (`vendorId`),
  KEY `idx_branch` (`branchId`),
  KEY `fk_vbm_user` (`createdByUserId`),
  CONSTRAINT `fk_vbm_branch` FOREIGN KEY (`branchId`) REFERENCES `branch` (`id`),
  CONSTRAINT `fk_vbm_company` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`),
  CONSTRAINT `fk_vbm_user` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`),
  CONSTRAINT `fk_vbm_vendor` FOREIGN KEY (`vendorId`) REFERENCES `vendor` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor_branch_mapping`
--

LOCK TABLES `vendor_branch_mapping` WRITE;
/*!40000 ALTER TABLE `vendor_branch_mapping` DISABLE KEYS */;
INSERT INTO `vendor_branch_mapping` VALUES (1,6,5,7,'ACTIVE',NULL,NULL,NULL,1,23,'2026-08-01 14:33:06','2026-08-01 14:33:06');
/*!40000 ALTER TABLE `vendor_branch_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor_payment`
--

DROP TABLE IF EXISTS `vendor_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendor_payment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `paymentNumber` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `companyId` int NOT NULL,
  `vendorId` int NOT NULL,
  `purchaseInvoiceId` int DEFAULT NULL,
  `paymentDate` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `amount` decimal(12,2) NOT NULL,
  `paymentMethod` enum('CASH','BANK','UPI','CARD','CHEQUE','WALLET') COLLATE utf8mb4_unicode_ci NOT NULL,
  `referenceNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdByUserId` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `transactionType` enum('CREDIT','PAYMENT') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CREDIT',
  `updatedByUserId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `VendorPayment_companyId_paymentNumber_key` (`companyId`,`paymentNumber`),
  KEY `VendorPayment_companyId_idx` (`companyId`),
  KEY `VendorPayment_vendorId_idx` (`vendorId`),
  KEY `VendorPayment_purchaseInvoiceId_fkey` (`purchaseInvoiceId`),
  KEY `VendorPayment_createdByUserId_fkey` (`createdByUserId`),
  KEY `VendorPayment_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `VendorPayment_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `VendorPayment_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor_payment`
--

LOCK TABLES `vendor_payment` WRITE;
/*!40000 ALTER TABLE `vendor_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `vendor_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wa_balance`
--

DROP TABLE IF EXISTS `wa_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wa_balance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `currentBalance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `totalSpent` decimal(12,2) NOT NULL DEFAULT '0.00',
  `totalRecharged` decimal(12,2) NOT NULL DEFAULT '0.00',
  `costPerMessage` decimal(12,4) NOT NULL DEFAULT '0.5000',
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wa_balance_companyId_unique` (`companyId`),
  CONSTRAINT `wa_balance_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wa_balance`
--

LOCK TABLES `wa_balance` WRITE;
/*!40000 ALTER TABLE `wa_balance` DISABLE KEYS */;
INSERT INTO `wa_balance` VALUES (1,6,10000.00,0.00,0.00,0.5000,'2026-07-31 12:18:59.668');
/*!40000 ALTER TABLE `wa_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wa_balance_transaction`
--

DROP TABLE IF EXISTS `wa_balance_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wa_balance_transaction` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RECHARGE',
  `amount` decimal(12,2) NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `wa_balance_transaction_companyId_idx` (`companyId`),
  KEY `wa_balance_transaction_createdAt_idx` (`createdAt`),
  CONSTRAINT `wa_balance_transaction_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wa_balance_transaction`
--

LOCK TABLES `wa_balance_transaction` WRITE;
/*!40000 ALTER TABLE `wa_balance_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `wa_balance_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wa_campaign`
--

DROP TABLE IF EXISTS `wa_campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wa_campaign` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `templateId` int DEFAULT NULL,
  `templateName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `totalRecipients` int NOT NULL DEFAULT '0',
  `sentCount` int NOT NULL DEFAULT '0',
  `failedCount` int NOT NULL DEFAULT '0',
  `scheduledAt` datetime(3) DEFAULT NULL,
  `sentAt` datetime(3) DEFAULT NULL,
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `wa_campaign_companyId_fkey` (`companyId`),
  KEY `wa_campaign_templateId_fkey` (`templateId`),
  KEY `wa_campaign_createdByUserId_fkey` (`createdByUserId`),
  KEY `wa_campaign_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `wa_campaign_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `wa_campaign_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `wa_campaign_templateId_fkey` FOREIGN KEY (`templateId`) REFERENCES `wa_template` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `wa_campaign_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wa_campaign`
--

LOCK TABLES `wa_campaign` WRITE;
/*!40000 ALTER TABLE `wa_campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `wa_campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wa_campaign_item`
--

DROP TABLE IF EXISTS `wa_campaign_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wa_campaign_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaignId` int NOT NULL,
  `customerId` int DEFAULT NULL,
  `customerName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `sentAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `wa_campaign_item_campaignId_fkey` (`campaignId`),
  KEY `wa_campaign_item_customerId_fkey` (`customerId`),
  CONSTRAINT `wa_campaign_item_campaignId_fkey` FOREIGN KEY (`campaignId`) REFERENCES `wa_campaign` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `wa_campaign_item_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `customer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wa_campaign_item`
--

LOCK TABLES `wa_campaign_item` WRITE;
/*!40000 ALTER TABLE `wa_campaign_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `wa_campaign_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wa_message`
--

DROP TABLE IF EXISTS `wa_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wa_message` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `billNo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `cost` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `sentAt` datetime(3) DEFAULT NULL,
  `error` text COLLATE utf8mb4_unicode_ci,
  `templateName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `wa_message_companyId_idx` (`companyId`),
  KEY `wa_message_sentAt_idx` (`sentAt`),
  KEY `wa_message_createdByUserId_fkey` (`createdByUserId`),
  CONSTRAINT `wa_message_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `wa_message_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wa_message`
--

LOCK TABLES `wa_message` WRITE;
/*!40000 ALTER TABLE `wa_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `wa_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wa_template`
--

DROP TABLE IF EXISTS `wa_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wa_template` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `footer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `params` int NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `lastSyncAt` datetime(3) DEFAULT NULL,
  `sampleValues` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `paramLabels` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wa_template_companyId_name_key` (`companyId`,`name`),
  KEY `wa_template_companyId_idx` (`companyId`),
  KEY `wa_template_createdByUserId_fkey` (`createdByUserId`),
  KEY `wa_template_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `wa_template_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `wa_template_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `wa_template_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `wa_template_chk_1` CHECK ((`sampleValues` is not null)),
  CONSTRAINT `wa_template_chk_2` CHECK ((`paramLabels` is not null))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wa_template`
--

LOCK TABLES `wa_template` WRITE;
/*!40000 ALTER TABLE `wa_template` DISABLE KEYS */;
INSERT INTO `wa_template` VALUES (2,6,'bill','en_US','UTILITY — transactional (bills, receipts, alerts)',NULL,'Hi Yuvanth,How r u?',NULL,0,'DRAFT',NULL,'[]','[]',0,23,23,'2026-08-01 14:50:48.967','2026-08-01 14:51:21.905');
/*!40000 ALTER TABLE `wa_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallet_transaction`
--

DROP TABLE IF EXISTS `wallet_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallet_transaction` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `customerId` int NOT NULL,
  `cardNumber` varchar(191) DEFAULT NULL,
  `employeeId` varchar(191) DEFAULT NULL,
  `customerName` varchar(191) DEFAULT NULL,
  `mobile` varchar(191) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `paymentMode` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'Completed',
  `transactionType` varchar(191) NOT NULL DEFAULT 'TOP_UP',
  `remarks` varchar(191) DEFAULT NULL,
  `createdByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `wallet_transaction_companyId_fkey` (`companyId`),
  KEY `wallet_transaction_customerId_fkey` (`customerId`),
  KEY `wallet_transaction_createdByUserId_fkey` (`createdByUserId`),
  CONSTRAINT `wallet_transaction_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `wallet_transaction_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `wallet_transaction_customerId_fkey` FOREIGN KEY (`customerId`) REFERENCES `customer` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallet_transaction`
--

LOCK TABLES `wallet_transaction` WRITE;
/*!40000 ALTER TABLE `wallet_transaction` DISABLE KEYS */;
INSERT INTO `wallet_transaction` VALUES (1,6,15,'CUS-0001','CUS-0001','Yuvanth','9876543210',500.00,'Cash','Completed','TOP_UP',NULL,23,'2026-07-31 03:47:53.177');
/*!40000 ALTER TABLE `wallet_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wastage`
--

DROP TABLE IF EXISTS `wastage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wastage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `companyId` int NOT NULL,
  `wastageNo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productionCategory` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numberOfProducts` int NOT NULL DEFAULT '0',
  `createdByUserId` int DEFAULT NULL,
  `updatedByUserId` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wastage_companyId_wastageNo_key` (`companyId`,`wastageNo`),
  KEY `wastage_createdAt_idx` (`createdAt`),
  KEY `wastage_createdByUserId_fkey` (`createdByUserId`),
  KEY `wastage_updatedByUserId_fkey` (`updatedByUserId`),
  CONSTRAINT `wastage_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `wastage_createdByUserId_fkey` FOREIGN KEY (`createdByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `wastage_updatedByUserId_fkey` FOREIGN KEY (`updatedByUserId`) REFERENCES `User` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wastage`
--

LOCK TABLES `wastage` WRITE;
/*!40000 ALTER TABLE `wastage` DISABLE KEYS */;
/*!40000 ALTER TABLE `wastage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wastage_item`
--

DROP TABLE IF EXISTS `wastage_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wastage_item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `wastageId` int NOT NULL,
  `productId` int NOT NULL,
  `quantity` decimal(12,3) NOT NULL,
  `companyId` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `wastage_item_productId_idx` (`productId`),
  KEY `wastage_item_companyId_idx` (`companyId`),
  KEY `wastage_item_wastageId_fkey` (`wastageId`),
  CONSTRAINT `wastage_item_companyId_fkey` FOREIGN KEY (`companyId`) REFERENCES `company` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `wastage_item_productId_fkey` FOREIGN KEY (`productId`) REFERENCES `product` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `wastage_item_wastageId_fkey` FOREIGN KEY (`wastageId`) REFERENCES `wastage` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wastage_item`
--

LOCK TABLES `wastage_item` WRITE;
/*!40000 ALTER TABLE `wastage_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `wastage_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'billora'
--

--
-- Dumping routines for database 'billora'
--
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-02 11:47:57
